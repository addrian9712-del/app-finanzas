import React from "react";
import { useNavigate } from "react-router-dom";

import { svg } from "../../assets/svg";
import { AppRoutes } from "../../routes";
import { useAppSelector } from "../../store";
import styles from "../../modules/tabs/more.module.scss";

export const More: React.FC = () => {
  const navigate = useNavigate();

  const { bottomBarHeight, safeAreaInsetBottom, headerHeight } = useAppSelector(
    (state) => state.appReducer
  );

  const menuItems = [
    {
      id: 1,
      title: "Add new card",
      icon: svg.CreditCardSvg,
      link: AppRoutes.OPEN_NEW_CARD,
    },
    {
      id: 2,
      title: "Create invoice",
      icon: svg.EditSvg,
      link: AppRoutes.CREATE_INVOICE,
    },
    {
      id: 3,
      title: "Statistics",
      icon: svg.BarChartSvg,
      link: AppRoutes.STATISTICS,
    },
    {
      id: 4,
      title: "Scanner QR",
      icon: svg.ScannerSvg,
      link: null,
    },
    {
      id: 5,
      title: "FAQ",
      icon: svg.HelpCircleSvg,
      link: AppRoutes.FAQ,
    },
    {
      id: 6,
      title: "Support",
      icon: svg.MessageSvg,
      link: null,
    },
    {
      id: 7,
      title: "Charity",
      icon: svg.HeartSvg,
      link: null,
    },
    {
      id: 8,
      title: "Privacy policy",
      icon: svg.FileTextSvg,
      link: AppRoutes.PRIVACY_POLICY,
    },
  ];

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: bottomBarHeight + safeAreaInsetBottom + 20,
        }}
      >
        <h2 className={styles.title}>More</h2>
        <div className={styles.menuGrid}>
          {menuItems.map((item) => {
            return (
              <div
                key={item.id}
                className={styles.menuBtn}
                onClick={() => {
                  if (item.link) {
                    navigate(item.link);
                  } else {
                    alert("This feature is not implemented yet.");
                  }
                }}
              >
                <item.icon />
                <h5 className={styles.menuBtnTitle}>{item.title}</h5>
              </div>
            );
          })}
        </div>
      </main>
    );
  };

  return renderContent();
};
