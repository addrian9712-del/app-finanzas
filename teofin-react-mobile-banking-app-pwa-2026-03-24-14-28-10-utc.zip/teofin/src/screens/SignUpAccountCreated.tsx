import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';

import styles from '../modules/sign-up-account-created.module.scss';

import bg03 from '../assets/bg/03.png';

export const SignUpAccountCreated: React.FC = () => {
  const navigate = useNavigate();

  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const {safeAreaInsetBottom, safeAreaInsetTop} = useAppSelector(
    (state) => state.appReducer,
  );

  const buttonsRef = useRef<HTMLDivElement>(null);
  const [buttonSectionHeight, setButtonSectionHeight] = useState(0);

  useEffect(() => {
    if (buttonsRef.current) {
      const height = buttonsRef.current.offsetHeight;
      setButtonSectionHeight(height);
    }
  }, []);

  const renderBackground = () => {
    return (
      <img
        src={bg03}
        alt='bg'
        className={styles.background}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{
          marginTop: safeAreaInsetTop,
          marginBottom: buttonSectionHeight,
        }}
      >
        <svg.PersonalBankingSvg />
        <h2 className={styles.title}>Account created!</h2>
        <p className={`t16 ${styles.text}`}>
          Your account had beed created successfully.
        </p>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonsRef}
        className={styles.buttonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title='Done'
          onClick={() => {
            navigate(AppRoutes.TAB_NAVIGATOR, {
              replace: true,
            });
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      {renderBackground()}
      {renderContent()}
      {renderButton()}
    </components.MotionWrapper>
  );
};
