import React, {useRef, useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/open-moneybox.module.scss';

export const OpenMoneybox: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const navigate = useNavigate();

  const buttonRef = useRef<HTMLDivElement>(null);

  const [buttonSectionHeight, setButtonSectionHeight] = useState(0);

  const [amount, setAmount] = useState(1200);
  const [selectedCard, setSelectedCard] = useState<number | null>(null);
  const [amountPerDay, setAmountPerDay] = useState(10);
  const [selectedAmount, setSelectedAmount] = useState('per day');

  const amountParts = amount.toFixed(2).split('.');

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const [form, setForm] = useState({
    goal: '',
  });

  const handleOpenMoneybox = () => {
    navigate(AppRoutes.TAB_NAVIGATOR);
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setButtonSectionHeight(height);
    }
  }, []);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="Open moneybox"
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.openMoneyboxMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: buttonSectionHeight + 20,
        }}
      >
        {/* The amount you want to achieve: */}
        <section className={styles.openMoneyboxSection}>
          <span className={'t12 ' + styles.openMoneyboxLabel}>
            The amount you want to achieve:
          </span>
          <div
            className={styles.openMoneyboxAmountBtn}
            onClick={() => {
              const result = window.prompt('Enter amount', amount.toString());
              if (result !== null) {
                const parsedAmount = parseFloat(result);
                if (!isNaN(parsedAmount) && parsedAmount > 0) {
                  setAmount(parsedAmount);
                }
              }
            }}
          >
            <span className={styles.openMoneyboxAmount}>
              ${amountParts[0]}.
              <span className={styles.openMoneyboxAmountFrac}>
                {amountParts[1]}
              </span>
            </span>
          </div>
        </section>

        {/* Use card: */}
        <section className={styles.openMoneyboxSectionCard}>
          <span className={'t12 ' + styles.openMoneyboxLabel}>Use card:</span>
          <ul className={styles.openMoneyboxCardsList}>
            {cards.map((card) => {
              const isSelected = selectedCard === card.id;
              return (
                <div
                  key={card.id}
                  className={
                    styles.openMoneyboxCardBtn +
                    (isSelected ? ' ' + styles.openMoneyboxCardBtnSelected : '')
                  }
                  onClick={() => {
                    setSelectedCard(card.id);
                  }}
                >
                  <div className={styles.openMoneyboxCardImg}>
                    <span className={styles.openMoneyboxCardImgText}>
                      teofin
                    </span>
                  </div>
                  <div className={styles.openMoneyboxCardDetails}>
                    <span className="t12">{card.number}</span>
                    <h6>{card.balance}</h6>
                  </div>
                </div>
              );
            })}
          </ul>
        </section>

        {/* Choose period: */}
        <section className={styles.openMoneyboxSectionPeriod}>
          <ul className={styles.openMoneyboxPeriodList}>
            <li className={styles.openMoneyboxPeriodItem}>
              <button
                className={styles.openMoneyboxPeriodBtn}
                onClick={() => {
                  setSelectedAmount('per day');
                }}
              >
                <span className={styles.openMoneyboxPeriodRadio}>
                  {selectedAmount === 'per day' && (
                    <span className={styles.openMoneyboxPeriodRadioDot} />
                  )}
                </span>
                <span
                  className={styles.openMoneyboxPeriodValue}
                  onClick={() => {
                    const result = window.prompt(
                      'Enter amount per day',
                      amountPerDay.toString(),
                    );
                    if (result !== null) {
                      const parsedAmount = parseFloat(result);
                      if (!isNaN(parsedAmount) && parsedAmount > 0) {
                        setAmountPerDay(parsedAmount);
                      }
                    }
                  }}
                >
                  <span className={styles.openMoneyboxPeriodValueText}>
                    {amountPerDay.toFixed(2)}
                  </span>
                </span>
                <span className="t16">USD per day;</span>
              </button>
            </li>
            <li className={styles.openMoneyboxPeriodItem}>
              <button
                className={styles.openMoneyboxPeriodBtn}
                onClick={() => {
                  setSelectedAmount('$1');
                }}
              >
                <span className={styles.openMoneyboxPeriodRadio}>
                  {selectedAmount === '$1' && (
                    <span className={styles.openMoneyboxPeriodRadioDot} />
                  )}
                </span>
                <span>Rounding up to $1 per transaction;</span>
              </button>
            </li>
            <li className={styles.openMoneyboxPeriodItem}>
              <button
                className={styles.openMoneyboxPeriodBtn}
                onClick={() => {
                  setSelectedAmount('$10');
                }}
              >
                <span className={styles.openMoneyboxPeriodRadio}>
                  {selectedAmount === '$10' && (
                    <span className={styles.openMoneyboxPeriodRadioDot} />
                  )}
                </span>
                <span>Rounding up to $10 per transaction.</span>
              </button>
            </li>
          </ul>
        </section>

        {/* Enter your goal */}
        <section>
          <components.InputField
            placeholder="Enter your goal"
            onClick={() => handleChangeField('goal', 'goal')}
            value={form.goal}
          />
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <section
        ref={buttonRef}
        className={styles.openMoneyboxButtonSection}
        style={{
          position: 'fixed',
          bottom: safeAreaInsetBottom,
        }}
      >
        <components.Button
          title="Open Moneybox"
          onClick={() => {
            handleOpenMoneybox();
          }}
        />
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
