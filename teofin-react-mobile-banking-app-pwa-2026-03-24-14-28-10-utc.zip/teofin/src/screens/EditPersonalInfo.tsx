import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {svg} from '../assets/svg';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/edit-personal-info.module.scss';

export const EditPersonalInfo: React.FC = () => {
  const navigate = useNavigate();

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  const [form, setForm] = useState({
    name: '',
    phoneNumber: '',
    email: '',
    birthDate: '',
    address: '',
  });

  const handleSave = () => {
    navigate(-1);
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return <components.Header showGoBack={true} title="Edit personal info" />;
  };

  const renderContent = () => {
    return (
      <main
        className={styles.editPersonalInfoMain}
        style={{
          paddingTop: headerHeight + 20,
        }}
      >
        {/* User photo */}
        <div
          className={styles.editPersonalInfoPhotoButton}
          onClick={() => {
            alert('User photo change functionality is not implemented yet.');
          }}
        >
          <img
            alt="user"
            src="https://george-fx.github.io/teofin-data/photos/01.jpg"
            className={styles.editPersonalInfoPhotoImg}
          />
          <svg.CameraSvg />
        </div>

        {/* Inputs */}
        <section className={styles.editPersonalInfoFieldsSection}>
          <components.InputField
            placeholder="Cristina Wolf"
            onClick={() => handleChangeField('name', 'name')}
            value={form.name}
          />
          <components.InputField
            placeholder="+171 123 456 7890"
            onClick={() => handleChangeField('phoneNumber', 'phone number')}
            value={form.phoneNumber}
          />
          <components.InputField
            placeholder="Enter your email"
            onClick={() => handleChangeField('email', 'email')}
            value={form.email}
          />
          <components.InputField
            placeholder="MM/DD/YYYY"
            onClick={() => handleChangeField('birthDate', 'birth date')}
            value={form.birthDate}
          />
          <components.InputField
            placeholder="Enter your address"
            onClick={() => handleChangeField('address', 'address')}
            value={form.address}
          />
        </section>

        {/* Button */}
        <components.Button
          title="Save"
          onClick={() => {
            handleSave();
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
