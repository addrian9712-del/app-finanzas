import React from 'react';

import {useAppSelector} from '../store';
import styles from '../modules/components/safe-area-view.module.scss';

type SafeAreaViewProps = {
  children: React.ReactNode;
};

export const SafeAreaView: React.FC<SafeAreaViewProps> = ({children}) => {
  const {safeAreaInsetTop} = useAppSelector((state) => state.appReducer);
  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  return (
    <div
      className={styles.safeAreaView}
      style={{
        paddingBottom: safeAreaInsetBottom ? `${safeAreaInsetBottom}px` : '0',
        paddingTop: safeAreaInsetTop ? `${safeAreaInsetTop}px` : '0',
      }}
    >
      {children}
    </div>
  );
};
