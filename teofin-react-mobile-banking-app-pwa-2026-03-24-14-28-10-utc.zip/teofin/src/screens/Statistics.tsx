import React, {useState, useEffect} from 'react';
import {AnimatePresence, motion} from 'framer-motion';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/statistics.module.scss';

import bg03 from '../assets/bg/03.png';

export const Statistics: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const statuses = ['Income', 'Expenses'];
  const cards = [
    {
      id: 1,
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
      transitions: [
        {
          category: 'Money transfer',
          transactions: 36,
          amount: -7923.52,
          percentage: 68,
          icon: svg.TransferSvg,
        },
        {
          category: 'Food products',
          transactions: 18,
          amount: -1398.27,
          percentage: 12,
          icon: svg.ShoppingCartSvg,
        },
        {
          category: 'Cafe and restaurants',
          transactions: 12,
          amount: -932.18,
          percentage: 8,
          icon: svg.CoffeeSvg,
        },
        {
          category: 'Medical supplies',
          note: 'Money transfer',
          amount: -466.09,
          percentage: 88,
          icon: svg.MedicalPlusSvg,
        },
      ],
    },
    {
      id: 2,
      number: '**** **** **** 8456',
      balance: '2 156.35 USD',
      transitions: [
        {
          category: 'Online shopping',
          transactions: 22,
          amount: -1543.75,
          percentage: 71,
          icon: svg.TransferSvg,
        },
        {
          category: 'Groceries',
          transactions: 9,
          amount: -389.12,
          percentage: 18,
          icon: svg.ShoppingCartSvg,
        },
        {
          category: 'Entertainment',
          transactions: 5,
          amount: -156.48,
          percentage: 7,
          icon: svg.CoffeeSvg,
        },
        {
          category: 'Insurance',
          note: 'Monthly payment',
          amount: -67.0,
          percentage: 4,
          icon: svg.MedicalPlusSvg,
        },
      ],
    },
  ];

  const [selectedStatus, setSelectedStatus] = useState(statuses[0]);
  const [selectedCard, setSelectedCard] = useState(cards[0]);
  const [showBottomModal, setShowBottomModal] = useState(false);

  useEffect(() => {
    let metaTag = document.querySelector('meta[name="theme-color"]');
    if (!metaTag) {
      metaTag = document.createElement('meta');
      metaTag.setAttribute('name', 'theme-color');
      document.head.appendChild(metaTag);
    }

    if (showBottomModal) {
      metaTag.setAttribute('content', '#767879');
    } else {
      metaTag.setAttribute('content', '#EDF0F2');
    }
  }, [showBottomModal]);

  const renderBackground = () => {
    return (
      <img
        src={bg03}
        alt='bg'
        className={styles.statisticsBg}
      />
    );
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Statistics'
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.statisticsMain}
        style={{paddingTop: headerHeight + 20}}
      >
        {/* Statuses */}
        <section>
          <ul className={styles.statisticsStatuses}>
            {statuses.map((status, index) => {
              return (
                <li
                  key={index}
                  style={{width: '100%'}}
                >
                  <button
                    className={
                      styles.statisticsStatusBtn +
                      ' ' +
                      (selectedStatus === status
                        ? styles.statisticsStatusBtnActive
                        : styles.statisticsStatusBtnInactive)
                    }
                    onClick={() => setSelectedStatus(status)}
                  >
                    <span
                      className={
                        styles.statisticsStatusText +
                        ' ' +
                        (selectedStatus === status
                          ? styles.statisticsStatusTextActive
                          : styles.statisticsStatusTextInactive)
                      }
                    >
                      {status}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Date with card */}
        <section className={styles.statisticsDateCardSection}>
          <div className={styles.statisticsDateRow}>
            <span className='t16'>Sep 1 - Sep 20, 2022</span>
            <svg.CalendarSvg />
          </div>
          <div
            className={styles.statisticsCardBtn}
            onClick={() => setShowBottomModal(true)}
          >
            <div className={styles.statisticsCardImg}>
              <span className={styles.statisticsCardImgText}>teofin</span>
            </div>
            <div className={styles.statisticsCardDetails}>
              <span className='t12'>{selectedCard.number}</span>
              <h6>{selectedCard.balance}</h6>
            </div>
            <svg.MoreVerticalSvg />
          </div>
        </section>

        {/* Chart */}
        <section className={styles.statisticsChartSection}>
          <div className={styles.statisticsChartRow}>
            <svg.ChartSvg />
          </div>
        </section>

        {/* Total */}
        <section className={styles.statisticsTotalSection}>
          <span className={styles.statisticsTotal}>
            - $ 11 654.
            <span className={styles.statisticsTotalFrac}>24</span>
          </span>
        </section>

        {/* Transactions */}
        <section>
          <ul className={styles.statisticsTransactionsList}>
            {selectedCard.transitions.map((transaction, index) => {
              return (
                <div
                  key={index}
                  className={styles.statisticsTransactionBtn}
                  onClick={() => {
                    alert(`Selected transaction: ${transaction.category}`);
                  }}
                >
                  <>
                    <transaction.icon />
                  </>
                  <div className={styles.statisticsTransactionDetails}>
                    <div className={styles.statisticsTransactionRow}>
                      <h6 className={styles.statisticsTransactionCategory}>
                        {transaction.category}
                      </h6>
                      <h6>{transaction.amount.toFixed(2)}</h6>
                    </div>
                    <div className={styles.statisticsTransactionSubRow}>
                      <span className='t12'>
                        {transaction.transactions} stransactions
                      </span>
                      <span
                        className={'t12 ' + styles.statisticsTransactionPercent}
                      >
                        {transaction.percentage}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </ul>
        </section>
      </main>
    );
  };

  const renderOverlay = () => {
    return (
      <AnimatePresence>
        {showBottomModal && (
          <motion.div
            initial={{opacity: 0}}
            animate={{opacity: 1}}
            exit={{opacity: 0}}
            transition={{duration: 0.4, ease: 'easeInOut'}}
            className={styles.statisticsOverlay}
            onClick={() => setShowBottomModal(false)}
          />
        )}
      </AnimatePresence>
    );
  };

  const renderBottomModal = () => {
    return (
      <AnimatePresence>
        {showBottomModal && (
          <motion.div
            initial={{y: '100%'}}
            animate={{y: 0}}
            exit={{y: '100%'}}
            transition={{type: 'keyframes', stiffness: 300, damping: 30}}
            className={styles.statisticsBottomModal}
            style={{paddingBottom: safeAreaInsetBottom + 20}}
          >
            <h4 style={{textAlign: 'center', marginBottom: 20}}>Choose card</h4>
            <ul className={styles.statisticsBottomModalList}>
              {cards.map((card) => {
                return (
                  <div
                    key={card.id}
                    className={styles.statisticsBottomModalCardBtn}
                    onClick={() => setSelectedCard(card)}
                  >
                    <div className={styles.statisticsBottomModalCardImg}>
                      <span className={styles.statisticsBottomModalCardImgText}>
                        teofin
                      </span>
                    </div>
                    <div className={styles.statisticsBottomModalCardDetails}>
                      <span className='t12'>{card.number}</span>
                      <h6>{card.balance}</h6>
                    </div>
                    <div className={styles.statisticsBottomModalCardRadio}>
                      {selectedCard.id === card.id && (
                        <div
                          className={styles.statisticsBottomModalCardRadioDot}
                        ></div>
                      )}
                    </div>
                  </div>
                );
              })}
            </ul>
            <components.Button
              title='Show statistics'
              onClick={() => setShowBottomModal(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderBackground()}
        {renderHeader()}
        {renderContent()}
        {renderOverlay()}
        {renderBottomModal()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
