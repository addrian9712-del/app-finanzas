import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {components} from '../components';
import styles from '../modules/new-password.module.scss';

export const NewPassword: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const navigate = useNavigate();

  const [form, setForm] = useState({
    newPassword: '',
    confirmPassword: '',
  });

  const handleChangePassword = () => {
    navigate(AppRoutes.FORGOT_PASSWORD_SENT_EMAIL, {replace: true});
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="New password"
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main className={styles.main}>
        <p className={`t16 ${styles.description}`}>
          Enter new password and confirm.
        </p>
        <components.InputField
          inputType="password"
          placeholder="New Password"
          containerStyle={{marginBottom: 10}}
          onClick={() => handleChangeField('newPassword', 'new password')}
          value={form.newPassword}
        />
        <components.InputField
          inputType="password"
          placeholder="Confirm Password"
          containerStyle={{marginBottom: 14}}
          onClick={() =>
            handleChangeField('confirmPassword', 'confirm password')
          }
          value={form.confirmPassword}
        />
        <components.Button
          title="Change Password"
          onClick={() => {
            handleChangePassword();
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
