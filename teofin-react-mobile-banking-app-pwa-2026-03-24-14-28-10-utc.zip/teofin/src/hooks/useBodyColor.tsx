import {useEffect} from 'react';

import {useAppDispatch} from '../store';
import {appActions} from '../store/appSlice';

export const useBodyColor = (color: string) => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    const prevColor = document.body.style.backgroundColor;
    document.body.style.backgroundColor = color;
    dispatch(appActions.setBodyColor(color));

    return () => {
      document.body.style.backgroundColor = prevColor;
    };
  }, [color, dispatch]);
};
