import React, {useEffect, useRef} from 'react';
import {isMobile} from 'react-device-detect';

import {svg} from '../assets/svg';
import {TabScreens} from '../routes';
import {useAppDispatch} from '../store';
import {useAppSelector} from '../store';
import {tabActions} from '../store/tabSlice';
import {appActions} from '../store/appSlice';

import styles from '../modules/components/bottom-tab-bar.module.scss';

const tabs = [
  {
    id: 1,
    screen: TabScreens.DASHBOARD,
    icon: svg.DashboardIconSvg,
  },
  {
    id: 2,
    screen: TabScreens.DEPOSITS,
    icon: svg.DepositIconSvg,
  },
  {
    id: 3,
    screen: TabScreens.LOANS,
    icon: svg.LoansIconSvg,
  },
  {
    id: 4,
    screen: TabScreens.NOTIFICATIONS,
    icon: svg.NotificationsIconSvg,
  },
  {
    id: 5,
    screen: TabScreens.MORE,
    icon: svg.MoreIconSvg,
  },
];

export const BottomTabBar: React.FC = () => {
  const dispatch = useAppDispatch();
  const {screen} = useAppSelector((state) => state.tabReducer);
  const bottomTabBarRef = useRef<HTMLDivElement>(null);
  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  useEffect(() => {
    if (bottomTabBarRef.current) {
      const height = bottomTabBarRef.current.offsetHeight;
      dispatch(appActions.setBottomBarHeight(height));
    }
  }, [dispatch]);

  return (
    <div
      className={styles.bottomTabBarWrapper}
      style={{
        bottom: safeAreaInsetBottom,
        maxWidth: isMobile ? '100%' : 'var(--screen-width)',
      }}
    >
      <footer
        className={styles.bottomTabBarFooter}
        ref={bottomTabBarRef}
      >
        {tabs.map((tab, index) => {
          const color =
            screen === tab.screen
              ? 'var(--link-color)'
              : 'var(--body-text-color)';
          const Icon = tab.icon;
          return (
            <button
              className={styles.tabButton}
              key={index}
              onClick={() => dispatch(tabActions.setScreen(tab.screen))}
              type='button'
            >
              <Icon />
              <span
                className={`t10 ${styles.tabLabel}`}
                style={{color}}
              >
                {tab.screen}
              </span>
            </button>
          );
        })}
      </footer>
      {safeAreaInsetBottom > 0 && (
        <div
          className={styles.safeArea}
          style={{
            bottom: 0,
            height: safeAreaInsetBottom,
          }}
        />
      )}
    </div>
  );
};
