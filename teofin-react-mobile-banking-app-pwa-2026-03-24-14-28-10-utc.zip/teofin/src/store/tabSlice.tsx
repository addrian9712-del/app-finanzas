import {createSlice} from '@reduxjs/toolkit';

import {TabScreens} from '../routes';

const initialState = {
  screen: TabScreens.DASHBOARD,
};

export const tabSlice = createSlice({
  name: 'tab',
  initialState,
  reducers: {
    setScreen: (state, action) => {
      state.screen = action.payload;
    },
  },
});

export const tabReducer = tabSlice.reducer;
export const tabActions = tabSlice.actions;
