import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {svg} from '../../assets/svg';
import {AppRoutes} from '../../routes';
import {useAppSelector} from '../../store';
import {components} from '../../components';
import styles from '../../modules/tabs/loans.module.scss';

export const Loans: React.FC = () => {
  const navigate = useNavigate();

  const loans = [
    {
      amount: -20532.0,
      currency: 'USD',
      rate: 13,
      periodMonths: 24,
      monthlyPayment: 1117.0,
      totalPaid: 4468.0,
      status: 'active',
      action: 'Repay',
    },
  ];

  const {bottomBarHeight, safeAreaInsetBottom, headerHeight} = useAppSelector(
    (state) => state.appReducer,
  );

  const [buttonHeight, setButtonHeight] = useState(0);
  const buttonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setButtonHeight(height);
    }
  }, []);

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: bottomBarHeight + buttonHeight + safeAreaInsetBottom,
        }}
      >
        <h2 className={styles.title}>Loans</h2>
        <>
          <span className={`t16 ${styles.sectionLabel}`}>Current loans</span>
          <div className={styles.loansList}>
            {loans.map((loan, index) => {
              return (
                <div
                  key={index}
                  className={styles.loanCard}
                >
                  {/* top section */}
                  <section className={styles.loanTop}>
                    <svg.LoansWalletSvg />
                    <span className={styles.loanAmount}>
                      {loan.amount}
                      <span className={styles.loanAmountFraction}>.00</span>
                      <span className={styles.loanAmountCurrency}>
                        {loan.currency}
                      </span>
                    </span>
                    <button
                      className={styles.loanActionBtn}
                      onClick={() => {
                        alert('Your logic for loan action here');
                      }}
                    >
                      <span className={styles.loanActionText}>
                        {loan.action}
                      </span>
                    </button>
                  </section>
                  {/* bottom section */}
                  <section>
                    <div className={styles.loanGrid}>
                      <span className='t12'>Rate</span>
                      <span className='t12'>Period</span>
                    </div>
                    <div className={`${styles.loanGrid} ${styles.loanGridMb}`}>
                      <h6>{loan.rate}%</h6>
                      <h6>{loan.periodMonths} months</h6>
                    </div>
                    <div className={styles.loanGrid}>
                      <span className='t12'>Monthly payment</span>
                      <span className='t12'>Total paid</span>
                    </div>
                    <div className={styles.loanGrid}>
                      <h6>
                        {loan.monthlyPayment.toFixed(2)} {loan.currency}
                      </h6>
                      <h6>
                        {loan.totalPaid.toFixed(2)} {loan.currency}
                      </h6>
                    </div>
                  </section>
                </div>
              );
            })}
          </div>
        </>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <section
        style={{
          position: 'fixed',
          width: '100%',
          paddingLeft: 20,
          paddingRight: 20,
          paddingTop: 20,
          paddingBottom: 20,
          maxWidth: 'var(--screen-width)',
          bottom: bottomBarHeight + safeAreaInsetBottom,
          backgroundColor: 'var(--anti-flash-white)',
        }}
      >
        <components.Button
          title='+ new Loan'
          onClick={() => {
            navigate(AppRoutes.OPEN_NEW_LOAN);
          }}
        />
      </section>
    );
  };

  return (
    <>
      {renderContent()}
      {renderButton()}
    </>
  );
};
