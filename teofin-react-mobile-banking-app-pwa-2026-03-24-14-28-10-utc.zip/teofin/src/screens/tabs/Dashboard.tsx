import React from 'react';
import {useNavigate} from 'react-router-dom';

import {items} from '../../items';
import {svg} from '../../assets/svg';
import {AppRoutes} from '../../routes';
import {useAppSelector} from '../../store';
import styles from '../../modules/tabs/dashboard.module.scss';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();

  const {headerHeight} = useAppSelector((state) => state.appReducer);
  const {bottomBarHeight} = useAppSelector((state) => state.appReducer);
  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  const actions = [
    {
      id: 1,
      title: 'Top-Up<br>Payment',
      icon: svg.TopUpSvg,
      link: AppRoutes.TOP_UP_PAYMENT,
    },
    {
      id: 2,
      title: 'Mobile<br>Payment',
      icon: svg.MobilePaymentSvg,
      link: AppRoutes.MOBILE_PAYMENT,
    },
    {
      id: 3,
      title: 'Money<br>Transfer',
      icon: svg.MoneyTransferSvg,
      link: AppRoutes.FUND_TRANSFER,
    },
    {
      id: 4,
      title: 'Make<br>Payment',
      icon: svg.MakeAPaymentSvg,
      link: AppRoutes.PAYMENTS,
    },
  ];

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const transactions = [
    {
      name: 'Adalyn Roth',
      category: 'Money transfer',
      amount: 140.0,
      icon: 'https://george-fx.github.io/teofin-data/icons/01.png',
      type: 'outcome',
      date: '2023-10-01',
      time: '14:30',
    },
    {
      name: 'Amazon',
      category: 'Online payments',
      amount: 239.57,
      icon: 'https://george-fx.github.io/teofin-data/icons/02.png',
      type: 'outcome',
      date: '2023-10-02',
      time: '10:15',
    },
    {
      name: 'Paypal',
      category: 'Deposits',
      amount: 700.0,
      icon: 'https://george-fx.github.io/teofin-data/icons/03.png',
      type: 'income',
      date: '2023-10-03',
      time: '09:45',
    },
  ];

  const renderContent = () => {
    return (
      <main
        className={styles.dashboardMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: bottomBarHeight + safeAreaInsetBottom + 20,
        }}
      >
        {/* Actions */}
        <section>
          <ul className={styles.dashboardActionsList}>
            {actions.map((action) => {
              return (
                <li key={action.id}>
                  <button
                    className={styles.dashboardActionButton}
                    onClick={() => {
                      navigate(action.link);
                    }}
                    type='button'
                  >
                    {action.icon ? <action.icon /> : null}
                    <span
                      className={`t10 ${styles.dashboardActionTitle}`}
                      dangerouslySetInnerHTML={{__html: action.title}}
                    />
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Cards */}
        <section className={styles.dashboardCardsSection}>
          <span className={`t12 ${styles.dashboardCardsLabel}`}>Cards</span>
          <div className={styles.dashboardCardsList}>
            {cards.map((card) => {
              return (
                <items.CardItem
                  key={card.id}
                  card={card}
                />
              );
            })}
          </div>
        </section>

        {/* Transactions */}
        <section>
          <div className={styles.dashboardTransactionsHeader}>
            <h4>Latest transactions</h4>
            <button
              className={styles.dashboardViewAllButton}
              onClick={() => {
                navigate(AppRoutes.TRANSACTION_HISTORY);
              }}
              type='button'
            >
              <span className={styles.dashboardViewAllText}>View all</span>
            </button>
          </div>
          <div className={styles.dashboardTransactionsList}>
            {transactions.map((transaction, index) => {
              return (
                <items.TransactionItem
                  key={index}
                  transaction={transaction}
                />
              );
            })}
          </div>
        </section>
      </main>
    );
  };

  return renderContent();
};
