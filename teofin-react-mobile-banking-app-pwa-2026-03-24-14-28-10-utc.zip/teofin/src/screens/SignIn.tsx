import React, {useState} from 'react';
import {Link} from 'react-router-dom';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {components} from '../components';

import styles from '../modules/sign-in.module.scss';

export const SignIn: React.FC = () => {
  const navigate = useNavigate();
  const [isRememberMe, setIsRememberMe] = useState(false);

  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const [form, setForm] = useState({
    email: '',
    password: '',
  });

  const handleSignIn = () => {
    navigate(AppRoutes.TAB_NAVIGATOR, {
      replace: true,
    });
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="Sign In"
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main className={styles.container}>
        <h1 className={styles.title}>
          Welcome to <br /> Teofin!
        </h1>
        <components.InputField
          className={styles.inputField}
          placeholder="cristinawolf@mail.com"
          value={form.email}
          onClick={() => handleChangeField('email', 'email')}
          isValid={form.email.length > 0 && form.email.includes('@')}
        />
        <components.InputField
          className={styles.inputFieldPassword}
          placeholder="••••••"
          inputType="password"
          value={form.password}
          onClick={() => handleChangeField('password', 'password')}
          isValid={form.password.length > 0}
        />
        <div className={styles.rememberRow}>
          <button
            className={styles.rememberBtn}
            onClick={() => setIsRememberMe(!isRememberMe)}
          >
            <div className={styles.checkbox}>
              {isRememberMe && <svg.CheckSvg />}
            </div>
            <span className="t16">Remember me</span>
          </button>

          <Link to={AppRoutes.FORGOT_PASSWORD} className={styles.forgotLink}>
            Lost your password?
          </Link>
        </div>

        <components.Button
          title="Sign In"
          containerStyle={{marginBottom: 30}}
          onClick={() => {
            handleSignIn();
          }}
        />
        <div className={styles.bottomRow}>
          <span className="t16">No account? </span>
          <Link className={`t16 ${styles.registerLink}`} to={AppRoutes.SIGN_UP}>
            Register now
          </Link>
        </div>
        <div className={styles.socialRow}>
          <button
            onClick={() => {
              alert('Facebook login logic goes here');
            }}
          >
            <svg.FacebookSvg />
          </button>
          <button
            onClick={() => {
              alert('Twitter login logic goes here');
            }}
          >
            <svg.TwitterSvg />
          </button>
          <button
            onClick={() => {
              alert('Google login logic goes here');
            }}
          >
            <svg.GoogleSvg />
          </button>
        </div>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
