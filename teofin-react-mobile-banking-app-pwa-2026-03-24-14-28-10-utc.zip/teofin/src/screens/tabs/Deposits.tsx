import React, {useRef, useState, useEffect} from 'react';
import {useNavigate} from 'react-router-dom';

import {svg} from '../../assets/svg';
import {AppRoutes} from '../../routes';
import {useAppSelector} from '../../store';
import styles from '../../modules/tabs/deposits.module.scss';

export const Deposits: React.FC = () => {
  const navigate = useNavigate();

  const [buttonHeight, setButtonHeight] = useState(0);

  const {bottomBarHeight, safeAreaInsetBottom, headerHeight} = useAppSelector(
    (state) => state.appReducer,
  );

  const buttonsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (buttonsRef.current) {
      const height = buttonsRef.current.offsetHeight;
      setButtonHeight(height);
    }
  }, []);

  const deposits = [
    {
      amount: 3000.0,
      currency: 'USD',
      interestRate: 8,
      profit: 60.57,
      period: {
        start: '2022-09-01',
        end: '2022-03-01',
      },
      status: 'active',
      icon: 'safe',
      actions: [
        {
          label: 'Top-Up',
          color: '#55ACEE',
          link: AppRoutes.TOP_UP_PAYMENT,
        },
        {
          label: 'Withdrawal',
          color: '#3EB290',
          link: null,
        },
      ],
    },
    {
      amount: 1500.0,
      currency: 'USD',
      interestRate: 10,
      profit: 150.0,
      period: {
        start: '2021-09-01',
        end: '2022-09-01',
      },
      status: 'completed',
      icon: 'check',
      actions: [
        {
          label: 'Extend',
          color: '#FF8A71',
          link: null,
        },
        {
          label: 'Withdrawal',
          color: '#3EB290',
          link: null,
        },
      ],
    },
  ];

  const moneyboxes = [
    {
      title: 'New iPhone Pro Max',
      targetAmount: 1200.0,
      currentAmount: 650.27,
      currency: 'USD',
      buttons: [
        {
          label: 'Top - Up',
          color: '#55ACEE',
          link: AppRoutes.TOP_UP_PAYMENT,
        },
        {
          label: 'Withdrawal',
          color: '#3EB290',
          link: null,
        },
      ],
    },
  ];

  const formatPeriod = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);

    const startStr = startDate.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
    });
    const endStr = endDate.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
    });
    const yearStr = endDate.getFullYear();

    return `${startStr} - ${endStr}, ${yearStr}`;
  };

  const renderContent = () => {
    return (
      <main
        className={styles.depositsMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: bottomBarHeight + buttonHeight + safeAreaInsetBottom,
        }}
      >
        <h2 className={styles.depositsTitle}>Deposits</h2>

        {/* Current deposits */}
        <section className={styles.section}>
          <span className={`t12 ${styles.sectionLabel}`}>Current deposits</span>
          <div className={styles.depositsList}>
            {deposits.map((deposit, index) => {
              return (
                <div
                  className={styles.depositCard}
                  key={index}
                >
                  {/* top section */}
                  <div className={styles.depositTop}>
                    <div className={styles.depositIcon}>
                      <svg.SafeDepositSvg />
                    </div>
                    <div className={styles.depositInfo}>
                      <div className={styles.depositInfoRow}>
                        <>
                          <span className={styles.depositAmount}>
                            {deposit.amount.toFixed(2)}
                          </span>
                          <span className={styles.depositCurrency}>
                            {deposit.currency}
                          </span>
                        </>
                        <h5 className={styles.depositInterest}>
                          {deposit.interestRate}%
                        </h5>
                      </div>
                      <div className={styles.depositPeriodRow}>
                        <>
                          <span className='t12'>
                            {formatPeriod(
                              deposit.period.start,
                              deposit.period.end,
                            )}
                          </span>
                        </>
                        <h5 className={`t12 ${styles.depositProfit}`}>
                          + {deposit.profit.toFixed(2)}
                        </h5>
                      </div>
                    </div>
                  </div>
                  {/* bottom section */}
                  <div className={styles.depositActions}>
                    {deposit.actions.map((action, actionIndex) => {
                      return (
                        <button
                          key={actionIndex}
                          className={styles.depositActionBtn}
                          style={{backgroundColor: action.color}}
                          onClick={() => {
                            if (action.link) {
                              navigate(action.link);
                            } else {
                              alert(
                                `Action "${action.label}" is not implemented yet.`,
                              );
                            }
                          }}
                        >
                          <span className={styles.depositActionLabel}>
                            {action.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Moneyboxes */}
        <section>
          <span className={`t12 ${styles.sectionLabel}`}>
            Current moneyboxes
          </span>
          {moneyboxes.map((moneybox, index) => {
            const [int, frac] = moneybox.currentAmount
              .toFixed(2)
              .split('.') as [string, string];
            return (
              <div
                className={styles.moneyboxCard}
                key={index}
              >
                <div className={styles.moneyboxHeader}>
                  <svg.PyggyBankSvg />
                  <span className={styles.moneyboxTitle}>{moneybox.title}</span>
                  <span>
                    {moneybox.currentAmount.toFixed(2)}{' '}
                    <span className={styles.moneyboxAmount}>
                      {moneybox.currency}
                    </span>
                  </span>
                </div>
                <div className={styles.moneyboxProgressBg}>
                  <div
                    className={styles.moneyboxProgress}
                    style={{
                      width: `${
                        (moneybox.currentAmount / moneybox.targetAmount) * 100
                      }%`,
                    }}
                  />
                </div>
                <div className={styles.moneyboxValue}>
                  <>
                    {int}
                    <span className={styles.moneyboxValueFrac}>
                      .{frac} {moneybox.currency}
                    </span>
                  </>
                </div>
                <div className={styles.moneyboxActions}>
                  {moneybox.buttons.map((button, buttonIndex) => {
                    return (
                      <button
                        key={buttonIndex}
                        className={styles.moneyboxActionBtn}
                        style={{backgroundColor: button.color}}
                        onClick={() => {
                          if (button.link) {
                            navigate(button.link);
                          } else {
                            alert(
                              `Action "${button.label}" is not implemented yet.`,
                            );
                          }
                        }}
                      >
                        <span className={styles.moneyboxActionLabel}>
                          {button.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </section>
      </main>
    );
  };

  const renderButtons = () => {
    return (
      <section
        ref={buttonsRef}
        className={styles.fixedButtons}
        style={{
          bottom: bottomBarHeight + safeAreaInsetBottom,
        }}
      >
        <div className={styles.fixedButtonsGrid}>
          <button
            className={styles.addMoneyboxBtn}
            onClick={() => navigate(AppRoutes.OPEN_MONEYBOX)}
          >
            <span className={styles.addMoneyboxLabel}>+ Moneybox</span>
          </button>
          <button
            className={styles.addDepositBtn}
            onClick={() => navigate(AppRoutes.OPEN_DEPOSIT)}
          >
            <span className={styles.addDepositLabel}>+ Deposit</span>
          </button>
        </div>
      </section>
    );
  };

  return (
    <>
      {renderContent()}
      {renderButtons()}
    </>
  );
};
