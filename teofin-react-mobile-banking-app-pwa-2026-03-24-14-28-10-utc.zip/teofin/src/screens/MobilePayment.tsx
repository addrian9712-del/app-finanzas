import React, {useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/mobile-payment.module.scss';

export const MobilePayment: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const navigate = useNavigate();

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const [form, setForm] = useState({
    phone: '',
  });

  const handleConfirm = () => {
    navigate(AppRoutes.PAYMENT_SUCCESS, {
      state: {amount},
      replace: true,
    });
  };

  const [amount, setAmount] = useState(10);

  const amountParts = amount.toFixed(2).split('.');

  const buttonRef = useRef<HTMLDivElement>(null);

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="Mobile payment"
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.mobilePaymentMain}
        style={{paddingTop: headerHeight + 20}}
      >
        <components.InputField
          placeholder="+1234567890"
          value={form.phone}
          onClick={() => handleChangeField('phone', 'phone number')}
          containerStyle={{marginBottom: 14}}
        />
        <span className={'t12 ' + styles.mobilePaymentBalanceLabel}>
          Your balance: 4 863.27 USD
        </span>
        <div className={styles.mobilePaymentAmountRow}>
          <button
            className={styles.mobilePaymentAmountBtn}
            onClick={() => {
              const result = window.prompt('Enter amount', amount.toString());
              if (result !== null) {
                const parsedAmount = parseFloat(result);
                if (!isNaN(parsedAmount) && parsedAmount > 0) {
                  setAmount(parsedAmount);
                }
              }
            }}
          >
            <span className={styles.mobilePaymentAmount}>
              ${amountParts[0]}.
              <span className={styles.mobilePaymentAmountFrac}>
                {amountParts[1]}
              </span>
            </span>
          </button>
          <span className="t12">No fees</span>
        </div>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonRef}
        className={styles.mobilePaymentButtonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title="Confirm"
          onClick={() => {
            handleConfirm();
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
