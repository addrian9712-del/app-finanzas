import {Header} from './Header';
import {Button} from './Button';
import {Switcher} from './Switcher';
import {InputField} from './InputField';
import {BottomTabBar} from './BottomTabBar';
import {SafeAreaView} from './SafeAreaView';
import {MotionWrapper} from './MotionWrapper';

export const components = {
  Button,
  Header,
  Switcher,
  InputField,
  BottomTabBar,
  SafeAreaView,
  MotionWrapper,
};
