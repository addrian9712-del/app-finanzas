import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/change-pin-code.module.scss';

export const ChangePinCode: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');
  const navigate = useNavigate();

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  const [form, setForm] = useState({
    currentPin: '',
    newPin: '',
    confirmNewPin: '',
  });

  const handleSubmit = () => {
    navigate(-1);
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return <components.Header showGoBack={true} title="Change PIN code" />;
  };

  const renderContent = () => {
    return (
      <main
        className={styles.changePinCodeMain}
        style={{
          paddingTop: headerHeight + 20,
        }}
      >
        <div className={styles.changePinCodeFields}>
          <components.InputField
            placeholder="Current PIN code"
            value={form.currentPin}
            inputType="password"
            onClick={() => handleChangeField('currentPin', 'current PIN code')}
          />
          <components.InputField
            placeholder="New PIN code"
            value={form.newPin}
            inputType="password"
            onClick={() => handleChangeField('newPin', 'new PIN code')}
          />
          <components.InputField
            placeholder="Confirm new PIN code"
            value={form.confirmNewPin}
            inputType="password"
            onClick={() =>
              handleChangeField('confirmNewPin', 'confirm new PIN code')
            }
          />
        </div>
        <components.Button
          title="Save"
          onClick={() => {
            handleSubmit();
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
