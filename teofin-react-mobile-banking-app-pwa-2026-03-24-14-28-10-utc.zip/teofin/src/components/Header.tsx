import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {AppRoutes} from '../routes';
import {svg} from '../assets/svg';
import {useAppSelector} from '../store';
import {useAppDispatch} from '../store';
import {appActions} from '../store/appSlice';

import styles from '../modules/components/header.module.scss';

import userIcon from '../assets/icons/31.png';

type Props = {
  title?: string;
  showGoBack?: boolean;
  showCreditCard?: boolean;
  showUser?: boolean;
  leftSideButtonClick?: () => void;
  rightSideButtonClick?: () => void;
  headerStyle?: React.CSSProperties;
  showBorder?: boolean;
  showCurrency?: boolean;
};

export const Header: React.FC<Props> = ({
  title,
  showGoBack,
  showCreditCard,
  showUser,
  headerStyle,
  showBorder = false,
  leftSideButtonClick,
  rightSideButtonClick,
  showCurrency = false,
}) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const headerHeightRef = useRef<HTMLDivElement>(null);

  const {rates} = useAppSelector((state) => state.exchangeReducer);

  const canGoBack = showGoBack && window.history.length > 1;

  const [headerHeightState, setHeaderHeightState] = useState(0);

  useEffect(() => {
    if (headerHeightRef.current) {
      const height = headerHeightRef.current.offsetHeight;
      setHeaderHeightState(height);
      dispatch(appActions.setHeaderHeight(headerHeightState));
    }
  }, [
    showGoBack,
    title,
    showCreditCard,
    showUser,
    headerHeightState,
    dispatch,
  ]);

  const renderLeftSide = () => {
    return (
      <div
        className={styles.leftButton}
        onClick={() => {
          if (canGoBack && showGoBack) {
            navigate(-1);
          } else if (showUser) {
            navigate(AppRoutes.PROFILE);
          } else if (leftSideButtonClick) {
            leftSideButtonClick();
          }
        }}
      >
        {showUser && (
          <div className={styles.profileUserIcon}>
            <img
              src={userIcon}
              alt='User Icon'
              className={styles.profileUserIcon}
            />
          </div>
        )}
        {showGoBack && <svg.GoBackSvg />}
      </div>
    );
  };

  const renderRightSide = () => {
    return (
      <button
        className={styles.rightButton}
        onClick={() => {
          if (rightSideButtonClick) {
            rightSideButtonClick();
          } else if (showCreditCard) {
            navigate(AppRoutes.CARD_MENU);
          }
        }}
      >
        {showCreditCard && <svg.HeaedrCardSvg />}
      </button>
    );
  };

  const renderCenter = () => {
    return (
      <div className={styles.center}>
        {title && <h4 className={styles.title}>{title}</h4>}
        {showCurrency && (
          <button
            className={styles.currencyButton}
            onClick={() => {
              navigate(AppRoutes.EXCHANGE_RATES);
            }}
          >
            <span className={`t16 ${styles.currencyText}`}>
              {rates.symbol} {rates.per1USD} / {rates.toUSD}
            </span>
          </button>
        )}
      </div>
    );
  };

  if (!showGoBack && !title && !showCreditCard && !showUser) {
    dispatch(appActions.setHeaderHeight(0));
    return null;
  }

  return (
    <header
      ref={headerHeightRef}
      className={styles.header}
      style={{
        borderBottom: showBorder ? '1px solid #E4E8ED' : 'none',
        ...headerStyle,
      }}
    >
      {renderLeftSide()}
      {renderCenter()}
      {renderRightSide()}
    </header>
  );
};
