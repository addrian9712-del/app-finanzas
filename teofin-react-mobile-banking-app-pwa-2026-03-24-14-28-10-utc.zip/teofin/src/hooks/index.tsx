import {useBodyColor} from './useBodyColor';
import {useThemeColor} from './useThemeColor';

export const hooks = {
  useBodyColor,
  useThemeColor,
};
