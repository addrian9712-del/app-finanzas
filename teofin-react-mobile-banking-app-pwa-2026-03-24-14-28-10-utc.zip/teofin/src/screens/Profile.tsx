import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {items} from '../items';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/profile.module.scss';

export const Profile: React.FC = () => {
  const navigate = useNavigate();

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  const [settings, setSettings] = useState({
    notifications: false,
    faceId: false,
  });

  const handleToggle = (key: keyof typeof settings) => (newValue: boolean) => {
    setSettings((prev) => ({...prev, [key]: newValue}));
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Profile'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.profileMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: 20,
        }}
      >
        {/* User info */}
        <section>
          <div
            className={styles.profileUserSectionButton}
            onClick={() => {
              navigate(AppRoutes.EDIT_PERSONAL_INFO);
            }}
          >
            <img
              alt='user'
              src='https://george-fx.github.io/teofin-data/photos/01.jpg'
              className={styles.profileUserImage}
            />
            <div className={styles.profileUserInfo}>
              <h4 className={styles.profileUserName}>Cristina Wolf</h4>
              <span className='t16'>+1 954 621 7845</span>
            </div>
          </div>
        </section>

        {/* Menu */}
        <section>
          <div className={styles.profileMenuSection}>
            <items.ProfileMenuItem
              leftSideIcon={<svg.ProfileMenuUserSvg />}
              title='Personal Info'
              rightSideIcon={<svg.RightArrowSvg />}
              onClick={() => {
                navigate(AppRoutes.EDIT_PERSONAL_INFO);
              }}
            />
            <items.ProfileMenuItem
              leftSideIcon={<svg.ProfileMenuMessageSvg />}
              title='Notifications'
              checked={settings.notifications}
              onToggle={handleToggle('notifications')}
            />
            <items.ProfileMenuItem
              leftSideIcon={<svg.ProfileMenuFaceIDSvg />}
              title='Face ID'
              checked={settings.faceId}
              onToggle={handleToggle('faceId')}
            />
            <items.ProfileMenuItem
              leftSideIcon={<svg.ProfileExitSvg />}
              title='Log Out'
              rightSideIcon={<svg.RightArrowSvg />}
              onClick={() => {
                navigate(AppRoutes.SIGN_IN, {
                  replace: true,
                });
              }}
            />
          </div>
        </section>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
