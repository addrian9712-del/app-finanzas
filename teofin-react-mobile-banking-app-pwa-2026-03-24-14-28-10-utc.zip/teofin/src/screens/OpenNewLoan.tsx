import React, {useRef, useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/open-new-loan.module.scss';

export const OpenNewLoan: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const navigate = useNavigate();

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const currencies = [
    {id: 1, label: 'USD'},
    {id: 2, label: 'EUR'},
  ];

  const depositPeriods = [
    {id: 1, label: '1 mon', value: 1},
    {id: 2, label: '3 mos', value: 3},
    {id: 3, label: '6 mos', value: 6},
    {id: 4, label: '12 mos', value: 12},
    {id: 5, label: '18 mos', value: 18},
    {id: 6, label: '24 mos', value: 24},
  ];

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const buttonRef = useRef<HTMLDivElement>(null);

  const [amount, setAmount] = useState(1000);
  const [buttonSectionHeight, setButtonSectionHeight] = useState(0);
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0].id);
  const [selectedDepositPeriod, setSelectedDepositPeriod] = useState(
    depositPeriods[0].id,
  );
  const [selectedCard, setSelectedCard] = useState<number | null>(null);
  const [earlyWithdrawal, setEarlyWithdrawal] = useState(false);

  const amountParts = amount.toFixed(2).split('.');

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setButtonSectionHeight(height);
    }
  }, []);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Open new loan'
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.openNewLoanMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: buttonSectionHeight + 20,
        }}
      >
        {/* Choose currency */}
        <section className={styles.openNewLoanSection}>
          <span className={`t12 ${styles.openNewLoanLabel}`}>
            Choose currency:
          </span>
          <ul className={styles.openNewLoanCurrencyList}>
            {currencies.map((currency) => {
              const selected = selectedCurrency === currency.id;
              return (
                <li key={currency.id}>
                  <div
                    className={
                      styles.openNewLoanCurrencyButton +
                      (selected ? ' ' + styles.selected : '')
                    }
                    onClick={() => {
                      setSelectedCurrency(currency.id);
                    }}
                  >
                    <h5>{currency.label}</h5>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Choose deposit period */}
        <section className={styles.openNewLoanSection}>
          <span className={`t12 ${styles.openNewLoanLabel}`}>
            Choose deposit period:
          </span>
          <ul className={styles.openNewLoanPeriodList}>
            {depositPeriods.map((period) => {
              const selected = selectedDepositPeriod === period.id;
              return (
                <li key={period.id}>
                  <div
                    className={
                      styles.openNewLoanPeriodButton +
                      (selected ? ' ' + styles.selected : '')
                    }
                    onClick={() => {
                      setSelectedDepositPeriod(period.id);
                    }}
                  >
                    <h5>{period.label}</h5>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Amount */}
        <section className={styles.openNewLoanSection}>
          <span className={`t12 ${styles.openNewLoanLabel}`}>Amount:</span>
          <div className={styles.openNewLoanAmountRow}>
            <button
              className={styles.openNewLoanAmountButton}
              onClick={() => {
                const result = window.prompt('Enter amount', amount.toString());
                if (result !== null) {
                  const parsedAmount = parseFloat(result);
                  if (!isNaN(parsedAmount) && parsedAmount > 0) {
                    setAmount(parsedAmount);
                  }
                }
              }}
              type='button'
            >
              <span className={styles.openNewLoanAmountValue}>
                ${amountParts[0]}.
                <span className={styles.openNewLoanAmountDecimal}>
                  {amountParts[1]}
                </span>
              </span>
            </button>
            <span className='t12'>You rate is 8%.</span>
          </div>
        </section>

        {/* Use card: */}
        <section className={styles.openNewLoanSectionLarge}>
          <span className={`t12 ${styles.openNewLoanLabel}`}>Use card:</span>
          <ul className={styles.openNewLoanCardList}>
            {cards.map((card) => {
              const selected = selectedCard === card.id;
              return (
                <div
                  key={card.id}
                  className={
                    styles.openNewLoanCardButton +
                    (selected ? ' ' + styles.selected : '')
                  }
                  onClick={() => {
                    setSelectedCard(card.id);
                  }}
                >
                  {/* Image */}
                  <div className={styles.openNewLoanCardImage}>
                    <span className={styles.openNewLoanCardImageText}>
                      teofin
                    </span>
                  </div>
                  {/* Details */}
                  <div className={styles.openNewLoanCardDetails}>
                    <span className='t12'>{card.number}</span>
                    <h6>{card.balance}</h6>
                  </div>
                </div>
              );
            })}
          </ul>
        </section>

        {/* Early deposit withdrawal */}
        <section>
          <div className={styles.openNewLoanEarlyRow}>
            <h5>Early deposit withdrawal</h5>
            <components.Switcher
              onClick={() => {
                setEarlyWithdrawal(!earlyWithdrawal);
              }}
              isActive={earlyWithdrawal}
            />
          </div>
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <section
        ref={buttonRef}
        className={styles.openNewLoanButtonSection}
        style={{
          bottom: safeAreaInsetBottom,
        }}
      >
        <components.Button
          title='open new loan'
          onClick={() => {
            navigate(AppRoutes.TAB_NAVIGATOR);
          }}
        />
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
