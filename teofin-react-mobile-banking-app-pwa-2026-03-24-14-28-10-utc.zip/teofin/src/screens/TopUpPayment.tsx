import React, {useState} from 'react';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/top-up-payment.module.scss';
import icon17 from '../assets/icons/17.png';
import icon18 from '../assets/icons/18.png';
import icon19 from '../assets/icons/19.png';
import icon20 from '../assets/icons/20.png';
import icon21 from '../assets/icons/21.png';
import icon22 from '../assets/icons/22.png';

export const TopUpPayment: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const [selectedCard, setSelectedCard] = useState<number | null>(null);

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const otherMethods = [
    {
      title: 'Card from another bank',
      icon: icon17,
    },
    {
      title: 'SWIFT',
      icon: icon18,
    },
    {
      title: 'SEPA',
      icon: icon19,
    },
    {
      title: 'Western Union',
      icon: icon20,
    },
    {
      title: 'Paypal',
      icon: icon21,
    },
    {
      title: 'Payoneer',
      icon: icon22,
    },
  ];

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Top-Up payment'
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.topUpMain}
        style={{
          paddingTop: headerHeight + 20,
        }}
      >
        {/* Cards */}
        <section className={styles.topUpSection}>
          <span className={`t12 ${styles.topUpLabel}`}>Cards</span>
          <div className={styles.topUpCardsList}>
            {cards.map((card) => {
              const selected = selectedCard === card.id;
              return (
                <div
                  key={card.id}
                  className={
                    styles.topUpCardButton +
                    (selected ? ' ' + styles.selected : '')
                  }
                  onClick={() => {
                    setSelectedCard(card.id);
                  }}
                >
                  {/* Image */}
                  <div className={styles.topUpCardImage}>
                    <span className={styles.topUpCardImageText}>teofin</span>
                  </div>
                  {/* Details */}
                  <div className={styles.topUpCardDetails}>
                    <span className='t12'>{card.number}</span>
                    <h6>{card.balance}</h6>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Entrepreneur accounts */}
        <section className={styles.topUpSection}>
          <span className={`t12 ${styles.topUpLabel}`}>
            Entrepreneur accounts
          </span>
          <div
            className={styles.topUpEntrepreneurButton}
            onClick={() => {
              alert('Selected method: Entrepreneur account');
            }}
          >
            <svg.EntrAccSvg />
            <>
              <span className='t12'>US**********************4571</span>
              <h6>39 863.62 USD</h6>
            </>
          </div>
        </section>

        {/* Other methods */}
        <section>
          <span className={`t12 ${styles.topUpLabel}`}>Other methods</span>
          <ul className={styles.topUpOtherMethodsList}>
            {otherMethods.map((method, index) => {
              return (
                <li key={index}>
                  <div
                    key={method.title}
                    className={styles.topUpOtherMethodButton}
                    onClick={() => {
                      alert(`Selected method: ${method.title}`);
                    }}
                  >
                    <img
                      src={method.icon}
                      alt={method.title}
                      className={styles.topUpOtherMethodIcon}
                    />
                    <h6 className={styles.topUpOtherMethodTitle}>
                      {method.title}
                    </h6>
                    {method.title !== 'Card from another bank' && (
                      <svg.InfoSvg />
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
