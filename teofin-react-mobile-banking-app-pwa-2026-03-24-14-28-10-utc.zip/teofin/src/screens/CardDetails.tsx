import React from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {items} from '../items';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/card-details.module.scss';

import bg from '../assets/bg/04.png';

export const CardDetails: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const navigate = useNavigate();

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  const limits = [
    {
      id: 1,
      type: 'Online payments',
      defaultLimit: '100 USD per day',
      icon: svg.GlobeSvg,
      link: AppRoutes.PAYMENTS,
    },
    {
      id: 2,
      type: 'ATM withdrawals',
      defaultLimit: '3000 USD per day',
      icon: svg.DollarSignSvg,
      link: null,
    },
  ];

  const security = [
    {
      title: 'Change PIN code',
      icon: svg.KeySvg,
      link: AppRoutes.CHANGE_PIN_CODE,
    },
    {
      title: 'Reissue the card',
      icon: svg.RefreshSvg,
      link: null,
    },
    {
      title: 'Block the card',
      icon: svg.LockSvg,
      link: null,
    },
    {
      title: 'Close the card',
      icon: svg.TrashSvg,
      link: null,
    },
  ];

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Card details'
        headerStyle={{backgroundColor: 'var(--white-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.cardDetailsMain}
        style={{
          paddingTop: headerHeight + 20,
        }}
      >
        {/* Card */}
        <section className={styles.cardDetailsCardSection}>
          <div
            className={styles.cardDetailsCard}
            style={{backgroundImage: `url(${bg})`}}
          >
            <span className={styles.cardDetailsCardType}>teofin platinum</span>
            <div
              className={styles.cardDetailsCardRow}
              style={{marginBottom: 'auto'}}
            >
              <span className={styles.cardDetailsCardNumber}>
                4358 **** **** 4253
              </span>
              <svg.CVVSvg />
            </div>
            <div
              className={styles.cardDetailsCardRow}
              style={{marginBottom: 6}}
            >
              <span className={styles.cardDetailsCardLabel}>balance</span>
              <span className={styles.cardDetailsCardLabel}>expire</span>
            </div>
            <div className={styles.cardDetailsCardRow}>
              <span className={styles.cardDetailsCardBalance}>
                $ 4 863
                <span className={styles.cardDetailsCardBalanceDecimal}>
                  .27
                </span>
              </span>
              <span className={styles.cardDetailsCardExpire}>12/24</span>
            </div>
          </div>
        </section>

        {/* Limits */}
        <section className={styles.cardDetailsLimitsSection}>
          <span className='t12'>Limits</span>
          <ul>
            {limits.map((limit, index) => {
              return (
                <items.LimitItem
                  key={limit.id}
                  limit={limit}
                />
              );
            })}
          </ul>
        </section>

        {/* Security */}
        <section>
          <span className={styles.cardDetailsSecurityLabel + ' t12'}>
            Security
          </span>
          <ul className={styles.cardDetailsSecurityList}>
            {security.map((item) => {
              return (
                <li key={item.title}>
                  <div
                    className={styles.cardDetailsSecurityButton}
                    onClick={() => {
                      if (item.link) {
                        navigate(item.link);
                      } else {
                        alert('This feature is not available yet.');
                      }
                    }}
                  >
                    <item.icon />
                    <h5
                      className={
                        styles.cardDetailsSecurityTitle +
                        (item.title === 'Block the card' ||
                        item.title === 'Close the card'
                          ? ' ' + styles.danger
                          : '')
                      }
                    >
                      {item.title}
                    </h5>
                    <svg.RightArrowSvg />
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
