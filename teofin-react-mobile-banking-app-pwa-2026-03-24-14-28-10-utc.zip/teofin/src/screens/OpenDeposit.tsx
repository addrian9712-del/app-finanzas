import React, {useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/open-deposit.module.scss';

export const OpenDeposit: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const currencies = [
    {id: 1, label: 'USD'},
    {id: 2, label: 'EUR'},
  ];

  const depositPeriods = [
    {id: 1, label: '1 mon', value: 1},
    {id: 2, label: '3 mos', value: 3},
    {id: 3, label: '6 mos', value: 6},
    {id: 4, label: '12 mos', value: 12},
    {id: 5, label: '18 mos', value: 18},
    {id: 6, label: '24 mos', value: 24},
  ];

  const navigate = useNavigate();

  const [amount, setAmount] = useState(1000);
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0].id);
  const [selectedDepositPeriod, setSelectedDepositPeriod] = useState(
    depositPeriods[0].id,
  );
  const [selectedCard, setSelectedCard] = useState<number | null>(null);
  const [earlyWithdrawal, setEarlyWithdrawal] = useState(false);

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const amountParts = amount.toFixed(2).split('.');

  const buttonRef = useRef<HTMLDivElement>(null);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Open deposit'
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.openDepositMain}
        style={{paddingTop: headerHeight + 20}}
      >
        {/* Choose currency */}
        <section className={styles.openDepositSection}>
          <span className={'t12 ' + styles.openDepositLabel}>
            Choose currency:
          </span>
          <ul className={styles.openDepositCurrencyList}>
            {currencies.map((currency) => {
              const isActive = selectedCurrency === currency.id;
              return (
                <li key={currency.id}>
                  <div
                    className={
                      styles.openDepositCurrencyBtn +
                      ' ' +
                      (isActive
                        ? styles.openDepositCurrencyBtnActive
                        : styles.openDepositCurrencyBtnInactive)
                    }
                    onClick={() => {
                      setSelectedCurrency(currency.id);
                    }}
                  >
                    <h5
                      className={
                        isActive
                          ? styles.openDepositCurrencyTextActive
                          : styles.openDepositCurrencyTextInactive
                      }
                    >
                      {currency.label}
                    </h5>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Choose deposit period */}
        <section className={styles.openDepositSection}>
          <span className={'t12 ' + styles.openDepositLabel}>
            Choose deposit period:
          </span>
          <ul className={styles.openDepositPeriodList}>
            {depositPeriods.map((period) => {
              const isActive = selectedDepositPeriod === period.id;
              return (
                <li key={period.id}>
                  <div
                    className={
                      styles.openDepositPeriodBtn +
                      ' ' +
                      (isActive
                        ? styles.openDepositPeriodBtnActive
                        : styles.openDepositPeriodBtnInactive)
                    }
                    onClick={() => {
                      setSelectedDepositPeriod(period.id);
                    }}
                  >
                    <h5
                      className={
                        isActive
                          ? styles.openDepositPeriodTextActive
                          : styles.openDepositPeriodTextInactive
                      }
                    >
                      {period.label}
                    </h5>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Amount */}
        <section className={styles.openDepositSection}>
          <span className={'t12 ' + styles.openDepositLabel}>Amount:</span>
          <div className={styles.openDepositAmountRow}>
            <button
              className={styles.openDepositAmountBtn}
              onClick={() => {
                const result = window.prompt('Enter amount', amount.toString());
                if (result !== null) {
                  const parsedAmount = parseFloat(result);
                  if (!isNaN(parsedAmount) && parsedAmount > 0) {
                    setAmount(parsedAmount);
                  }
                }
              }}
            >
              <span className={styles.openDepositAmount}>
                ${amountParts[0]}.
                <span className={styles.openDepositAmountFrac}>
                  {amountParts[1]}
                </span>
              </span>
            </button>
            <span className='t12'>You rate is 8%.</span>
          </div>
        </section>

        {/* Use card: */}
        <section className={styles.openDepositSectionCard}>
          <span className={'t12 ' + styles.openDepositLabel}>Use card:</span>
          <ul className={styles.openDepositCardsList}>
            {cards.map((card) => {
              const isSelected = selectedCard === card.id;
              return (
                <div
                  key={card.id}
                  className={
                    styles.openDepositCardBtn +
                    (isSelected ? ' ' + styles.openDepositCardBtnSelected : '')
                  }
                  onClick={() => {
                    setSelectedCard(card.id);
                  }}
                >
                  <div className={styles.openDepositCardImg}>
                    <span className={styles.openDepositCardImgText}>
                      teofin
                    </span>
                  </div>
                  <div className={styles.openDepositCardDetails}>
                    <span className='t12'>{card.number}</span>
                    <h6>{card.balance}</h6>
                  </div>
                </div>
              );
            })}
          </ul>
        </section>

        {/* Early deposit withdrawal */}
        <section>
          <div className={styles.openDepositEarlyWithdrawal}>
            <h5>Early deposit withdrawal</h5>
            <components.Switcher
              onClick={() => {
                setEarlyWithdrawal(!earlyWithdrawal);
              }}
              isActive={earlyWithdrawal}
            />
          </div>
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <section
        ref={buttonRef}
        className={styles.openDepositButtonSection}
        style={{position: 'fixed', bottom: safeAreaInsetBottom}}
      >
        <components.Button
          title='Open deposit'
          onClick={() => {
            navigate(AppRoutes.TAB_NAVIGATOR);
          }}
        />
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
