import React, {useEffect} from 'react';

import {hooks} from '../hooks';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/privacy-policy.module.scss';

export const PrivacyPolicy: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const {headerHeight} = useAppSelector((state) => state.appReducer);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const privacyPolicy = [
    {
      id: 1,
      title: '1. Terms',
      content: `By accessing this website, you are agreeing to be bound by these website Terms and Conditions of Use,
      applicable laws and regulations and their compliance. If you disagree with any of the stated terms and
      conditions, you are prohibited from using or accessing this site. The materials contained in this site
      are secured by relevant copyright and trademark law.`,
    },
    {
      id: 2,
      title: '2. Use Licence',
      content: `Permission is allowed to temporarily download one duplicate of the materials (data or programming)
      on Company's site for individual and non-business use only. This is just a permit of license and
      not an exchange of title, and under this permit, you may not:`,
    },
  ];

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Privacy policy'
        headerStyle={{backgroundColor: 'var(--white-color)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.privacyPolicyMain}
        style={{paddingTop: headerHeight + 20}}
      >
        <h2 className={styles.privacyPolicyTitle}>Privacy policy</h2>
        {privacyPolicy.map((item) => {
          return (
            <div
              key={item.id}
              className={styles.privacyPolicySection}
            >
              <h4 className={styles.privacyPolicySectionTitle}>{item.title}</h4>
              <p className='t16'>{item.content}</p>
            </div>
          );
        })}
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
