import {FAQ} from './FAQ';
import {SignIn} from './SignIn';
import {SignUp} from './SignUp';
import {Profile} from './Profile';
import {CardMenu} from './CardMenu';
import {Payments} from './Payments';
import {Statistics} from './Statistics';
import {OpenDeposit} from './OpenDeposit';
import {OpenNewLoan} from './OpenNewLoan';
import {NewPassword} from './NewPassword';
import {InvoiceSent} from './InvoiceSent';
import {OpenNewCard} from './OpenNewCard';
import {CardDetails} from './CardDetails';
import {IbanPayment} from './IBANPayment';
import {TopUpPayment} from './TopUpPayment';
import {OpenMoneybox} from './OpenMoneybox';
import {FundTransfer} from './FundTransfer';
import {PaymentFailed} from './PaymentFailed';
import {CreateIncoice} from './CreateInvoice';
import {PrivacyPolicy} from './PrivacyPolicy';
import {ExchangeRates} from './ExchangeRates';
import {MobilePayment} from './MobilePayment';
import {ChangePinCode} from './ChangePinCode';
import {ForgotPassword} from './ForgotPassword';
import {PaymentSuccess} from './PaymentSuccess';
import {EditPersonalInfo} from './EditPersonalInfo';
import {ConfirmationCode} from './ConfirmationCode';
import {TransactionHistory} from './TransactionHistory';
import {TransactionDetails} from './TransactionDetails';
import {SignUpAccountCreated} from './SignUpAccountCreated';
import {VerifyYourPhoneNumber} from './VerifyYourPhoneNumber';
import {ForgotPasswordSentEmail} from './ForgotPasswordSentEmail';

// tabs
import {Loans} from './tabs/Loans';
import {Dashboard} from './tabs/Dashboard';
import {Notification} from './tabs/Notification';

export const screens = {
  FAQ,
  Loans,
  SignIn,
  SignUp,
  Profile,
  CardMenu,
  Payments,
  Dashboard,
  Statistics,
  CardDetails,
  NewPassword,
  IbanPayment,
  OpenNewCard,
  InvoiceSent,
  OpenNewLoan,
  OpenDeposit,
  TopUpPayment,
  OpenMoneybox,
  FundTransfer,
  Notification,
  ChangePinCode,
  MobilePayment,
  PrivacyPolicy,
  CreateIncoice,
  PaymentFailed,
  ExchangeRates,
  ForgotPassword,
  PaymentSuccess,
  EditPersonalInfo,
  ConfirmationCode,
  TransactionDetails,
  TransactionHistory,
  SignUpAccountCreated,
  VerifyYourPhoneNumber,
  ForgotPasswordSentEmail,
};
