import React from 'react';

import {svg} from '../../assets/svg';
import {useAppSelector} from '../../store';
import styles from '../../modules/tabs/notification.module.scss';

export const Notification: React.FC = () => {
  const {bottomBarHeight, safeAreaInsetBottom, headerHeight} = useAppSelector(
    (state) => state.appReducer,
  );
  const notifications = [
    {
      id: 1,
      status: 'success',
      icon: svg.NtfCheckSvg,
      title: 'loan has been approved!',
      description: '',
      date: 'Aug 29, 2022 at 12:36 PM',
    },
    {
      id: 2,
      status: 'warning',
      icon: svg.NtfAlertSvg,
      title: 'The loan repayment period expires!',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      date: 'Aug 29, 2022 at 12:36 PM',
    },
    {
      id: 3,
      status: 'error',
      icon: svg.NtfRejectedSvg,
      title: 'Your loan application was rejected!',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
      date: 'Aug 29, 2022 at 12:36 PM',
    },
  ];

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: bottomBarHeight + safeAreaInsetBottom + 20,
        }}
      >
        <h2 className={styles.title}>Notifications</h2>
        <div className={styles.list}>
          {notifications.map((notification) => {
            return (
              <div
                className={styles.card}
                key={notification.id}
              >
                <div className={styles.cardHeader}>
                  <notification.icon />
                  <h5>{notification.title}</h5>
                </div>
                {notification.description && (
                  <p className={`t16 ${styles.cardDescription}`}>
                    {notification.description}
                  </p>
                )}
                <div className={styles.cardDivider} />
                <span className='t12'>{notification.date}</span>
              </div>
            );
          })}
        </div>
      </main>
    );
  };

  return renderContent();
};
