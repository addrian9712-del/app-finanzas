import React from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {useAppSelector} from '../store';
import {useAppDispatch} from '../store';
import {components} from '../components';
import {rates} from '../store/exchangeRates';
import {exchangeRatesActions} from '../store/exchangeRates';

import styles from '../modules/exchange-rates.module.scss';

export const ExchangeRates: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const {headerHeight} = useAppSelector((state) => state.appReducer);
  const eRates = useAppSelector((state) => state.exchangeReducer.rates);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Exchange rates'
        headerStyle={{backgroundColor: '#fff'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.exchangeRatesMain}
        style={{
          paddingTop: headerHeight + 8,
        }}
      >
        <div className={styles.exchangeRatesHeaderGrid}>
          <span>Currency</span>
          <span className={styles.exchangeRatesHeaderRight}>$1</span>
          <span className={styles.exchangeRatesHeaderRight}>in Dollars</span>
        </div>
        <ul className={styles.exchangeRatesList}>
          {rates.map((rate) => {
            const selected = eRates.symbol === rate.symbol;
            return (
              <li
                className={styles.exchangeRatesListItem}
                key={rate.code}
              >
                <div
                  className={
                    styles.exchangeRatesButton +
                    (selected ? ' ' + styles.selected : '')
                  }
                  onClick={() => {
                    dispatch(exchangeRatesActions.setExchangeRates(rate));
                    navigate(-1);
                  }}
                >
                  <div className={styles.exchangeRatesCurrency}>
                    <div className={styles.exchangeRatesCurrencyIcon}>
                      <img
                        src={rate.currencyIcon}
                        alt={rate.code}
                        className={styles.exchangeRatesCurrencyImg}
                      />
                    </div>
                    <div className={styles.exchangeRatesCurrencyInfo}>
                      <h5>{rate.code}</h5>
                      <span className='t12 number-of-lines-1'>{rate.name}</span>
                    </div>
                  </div>
                  <h5 className={styles.exchangeRatesValueRight}>
                    {rate.per1USD}
                  </h5>
                  <h5 className={styles.exchangeRatesValueRight}>
                    {rate.toUSD}
                  </h5>
                </div>
              </li>
            );
          })}
        </ul>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
