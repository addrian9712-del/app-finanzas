import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/card-menu.module.scss';

export const CardMenu: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const navigate = useNavigate();

  const buttonRef = useRef<HTMLDivElement>(null);

  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  const [buttonSectionHeight, setButtonSectionHeight] = useState(0);

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setButtonSectionHeight(height);
    }
  }, []);

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11',
      currency: 'USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27',
      currency: 'EUR',
    },
  ];

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Card menu'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{paddingBottom: buttonSectionHeight}}
      >
        {/* Cards */}
        <section className={styles.section}>
          <span className={`t12 ${styles.sectionTitle}`}>Cards</span>
          <div className={styles.cardList}>
            {cards.map((card) => {
              return (
                <div
                  key={card.id}
                  className={styles.cardBtn}
                  onClick={() => {
                    navigate(AppRoutes.CARD_DETAILS, {
                      state: {card},
                    });
                  }}
                >
                  {/* Image */}
                  <div className={styles.cardImage}>
                    <span className={styles.cardImageText}>teofin</span>
                  </div>
                  {/* Details */}
                  <div className={styles.cardDetails}>
                    <span className='t12'>{card.number}</span>
                    <h6>
                      {card.balance} {card.currency}
                    </h6>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Entrepreneur accounts */}
        <section className={styles.section}>
          <span className={`t12 ${styles.sectionTitle}`}>
            Entrepreneur accounts
          </span>
          <div
            className={styles.accountBtn}
            onClick={() => {
              alert('Your entrepreneur accounts are not available yet.');
            }}
          >
            <svg.EntrAccSvg />
            <div className={styles.accountDetails}>
              <span className='t12'>US**********************4571</span>
              <h6>39 863.62 USD</h6>
            </div>
          </div>
        </section>

        {/* Ongoing credits */}
        <section>
          <span className={`t12 ${styles.sectionTitle}`}>Ongoing credits</span>
          <div
            className={styles.creditBtn}
            onClick={() => {
              alert('Your ongoing credits are not available yet.');
            }}
          >
            <div className={styles.creditImage}>
              <span className={styles.cardImageText}>teofin</span>
            </div>
            <div className={styles.creditDetails}>
              <span className='t12'>**** **** 6547</span>
              <h6 className={styles.creditAmount}>1687.62 USD</h6>
            </div>
          </div>
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonRef}
        className={styles.buttonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <button
          onClick={() => {
            navigate(AppRoutes.OPEN_NEW_CARD);
          }}
        >
          <svg.AddANewCardSvg />
        </button>
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
