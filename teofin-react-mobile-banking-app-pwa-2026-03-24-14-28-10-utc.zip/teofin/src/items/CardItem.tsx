import React from 'react';
import {useNavigate} from 'react-router-dom';

import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import styles from '../modules/card-item.module.scss';

type Props = {
  card: {
    id: number;
    type: string;
    number: string;
    balance: string;
  };
};

export const CardItem: React.FC<Props> = ({card}) => {
  const navigate = useNavigate();

  return (
    <div
      className={styles.cardItemButton}
      onClick={() => {
        navigate(AppRoutes.CARD_DETAILS, {
          state: {card},
        });
      }}
    >
      {/* Image */}
      <span className={styles.cardImage}>
        <span className={styles.cardImageText}>teofin</span>
      </span>
      {/* Details */}
      <div className={styles.cardDetails}>
        <span className='t12'>{card.number}</span>
        <span>{card.balance}</span>
      </div>
      <svg.RightArrowSvg />
    </div>
  );
};
