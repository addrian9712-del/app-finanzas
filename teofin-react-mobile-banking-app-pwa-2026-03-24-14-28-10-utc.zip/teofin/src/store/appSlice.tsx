import {createSlice} from '@reduxjs/toolkit';

type AppState = {
  bodyColor?: string;
  themeColor?: string;
  headerHeight: number;
  bottomBarHeight: number;
  safeAreaInsetTop: number;
  safeAreaInsetBottom: number;
};

const initialState: AppState = {
  bodyColor: undefined,
  themeColor: undefined,
  headerHeight: 0,
  bottomBarHeight: 0,
  safeAreaInsetTop: 0,
  safeAreaInsetBottom: 0,
};

const appSlice = createSlice({
  name: 'app',
  initialState,
  reducers: {
    setHeaderHeight: (state, action) => {
      state.headerHeight = action.payload;
    },
    setBottomBarHeight: (state, action) => {
      state.bottomBarHeight = action.payload;
    },
    setSafeAreaInsetTop: (state, action) => {
      state.safeAreaInsetTop = action.payload;
    },
    setSafeAreaInsetBottom: (state, action) => {
      state.safeAreaInsetBottom = action.payload;
    },
    setBodyColor: (state, action) => {
      state.bodyColor = action.payload;
    },
    setThemeColor: (state, action) => {
      state.themeColor = action.payload;
    },
  },
});

export const appActions = appSlice.actions;
export const appReducer = appSlice.reducer;
