import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/invoice-sent.module.scss';

import bg03 from '../assets/bg/03.png';

export const InvoiceSent: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const navigate = useNavigate();
  const buttonsRef = useRef<HTMLDivElement>(null);
  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (buttonsRef.current) {
      const height = buttonsRef.current.offsetHeight;
      setHeight(height);
    }
  }, []);

  const renderBackground = () => {
    return (
      <img
        src={bg03}
        alt='bg'
        className={styles.invoiceSentBg}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.invoiceSentMain}
        style={{
          marginBottom: height + 20,
        }}
      >
        <svg.InvoiceMailSvg />
        <h2 className={styles.invoiceSentTitle}>
          Your invoice <br /> has been sent!
        </h2>
        <p className={`t16 ${styles.invoiceSentText}`}>
          Qui ex aute ipsum duis. Incididunt <br /> adipisicing voluptate
          laborum
        </p>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonsRef}
        className={styles.invoiceSentButtonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title='Done'
          onClick={() => {
            navigate(AppRoutes.TAB_NAVIGATOR, {
              replace: true,
            });
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderBackground()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
