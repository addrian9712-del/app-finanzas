import React from 'react';
import {useSelector} from 'react-redux';
import {AnimatePresence, motion} from 'framer-motion';

import {hooks} from '../hooks';
import {RootState} from '../store';
import {TabScreens} from '../routes';
import {components} from '../components';

import {More} from '../screens/tabs/More';
import {Loans} from '../screens/tabs/Loans';
import {Deposits} from '../screens/tabs/Deposits';
import {Dashboard} from '../screens/tabs/Dashboard';
import {Notification} from '../screens/tabs/Notification';

export const TabNavigator: React.FC = () => {
  const {screen} = useSelector((state: RootState) => state.tabReducer);

  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const renderCurrentScreen = () => {
    switch (screen) {
      case TabScreens.DASHBOARD:
        return <Dashboard />;
      case TabScreens.DEPOSITS:
        return <Deposits />;
      case TabScreens.LOANS:
        return <Loans />;
      case TabScreens.NOTIFICATIONS:
        return <Notification />;
      case TabScreens.MORE:
        return <More />;
      default:
        return null;
    }
  };

  const screenVariants = {
    initial: {opacity: 0, x: 40},
    animate: {opacity: 1, x: 0},
    exit: {opacity: 0, x: -40},
  };

  const renderHeader = () => {
    return (
      <components.Header
        showCurrency={true}
        showGoBack={false}
        showUser={true}
        showCreditCard={true}
        headerStyle={{backgroundColor: '#EDF0F2'}}
        showBorder={true}
      />
    );
  };

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  return (
    <components.MotionWrapper>
      {renderHeader()}
      <div
        style={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <AnimatePresence
          mode='wait'
          initial={false}
        >
          <motion.div
            key={screen}
            variants={screenVariants}
            initial='initial'
            animate='animate'
            exit='exit'
            transition={{duration: 0.25, ease: [0.87, 0, 0.13, 1]}}
            style={{height: '100%'}}
          >
            {renderCurrentScreen()}
          </motion.div>
        </AnimatePresence>
      </div>
      {renderBottomBar()}
    </components.MotionWrapper>
  );
};
