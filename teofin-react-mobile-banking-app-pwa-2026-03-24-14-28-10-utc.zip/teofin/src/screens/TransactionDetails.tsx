import {useLocation} from 'react-router-dom';
import React, {useEffect, useRef, useState} from 'react';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/transaction-details.module.scss';

export const TransactionDetails: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');
  const location = useLocation();
  const {transaction} = location.state as {transaction: any};

  const [height, setHeight] = useState(0);

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const buttonsRef = useRef<HTMLDivElement>(null);

  const transactionDetails = [
    {label: 'Sent to', value: transaction.to || 'Hillary Holmes'},
    {label: 'Card', value: '**** 4253'},
    {
      label: 'Amount',
      value: transaction.amount ? `$ ${transaction.amount}` : '$ 263.57',
    },
    {label: 'Fee', value: '1.8 USD'},
    {label: 'Residual balance', value: '4 863.27 USD'},
  ];

  const date = new Date(transaction.date || '2022-09-10T11:34:00Z');

  const options: any = {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  };

  const formatted = date
    .toLocaleString('en-US', options)
    .replace(',', '')
    .replace(/(\d{4}) (.*)/, '$1 at $2');

  useEffect(() => {
    if (buttonsRef.current) {
      const height = buttonsRef.current.offsetHeight;
      setHeight(height);
    }
  }, []);

  const renderHeader = () => {
    return <components.Header showGoBack={true} />;
  };

  const renderContent = () => {
    return (
      <main
        className={styles.transactionDetailsMain}
        style={{
          paddingTop: headerHeight,
          paddingBottom: height,
        }}
      >
        <svg.RepeatSvg />
        <span className={`t12 ${styles.transactionDetailsDate}`}>
          {/* Sep 10, 2022 at 11:34 AM */}
          {formatted}
        </span>
        <div className={styles.transactionDetailsAmount}>
          {transaction.amount ? `$ ${transaction.amount}` : '$ 263'}
        </div>
        <span className={`t16 ${styles.transactionDetailsSentTo}`}>
          Sent to {transaction.name || 'Hillary Holmes'}
        </span>
        <svg.DetailsSuccessSvg />

        <div className={styles.transactionDetailsInfoBlock}>
          {transactionDetails.map((item, index) => {
            return (
              <div
                key={index}
                className={styles.transactionDetailsInfoRow}
              >
                <span className='t16'>{item.label}</span>
                <h5>{item.value}</h5>
              </div>
            );
          })}
        </div>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <section
        ref={buttonsRef}
        className={styles.transactionDetailsButtonSection}
        style={{
          bottom: safeAreaInsetBottom > 0 ? safeAreaInsetBottom : 0,
        }}
      >
        <components.Button
          title='Download PDF'
          onClick={() => {
            alert('Download PDF clicked');
          }}
        />
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
