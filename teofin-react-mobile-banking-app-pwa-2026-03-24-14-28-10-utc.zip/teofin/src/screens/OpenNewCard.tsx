import React, {useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {components} from '../components';
import {useAppSelector} from '../store';

import bg03 from '../assets/bg/03.png';
import styles from '../modules/open-new-card.module.scss';

export const OpenNewCard: React.FC = () => {
  const navigate = useNavigate();
  const canGoBack = window.history.length > 1;
  const {safeAreaInsetBottom, headerHeight} = useAppSelector(
    (state) => state.appReducer,
  );

  const currencies = ['USD', 'EUR'];

  const cardTypes = ['Debet', 'Credit'];
  const paymentSystems = ['Visa', 'MasterCard'];

  const [selectedCardType, setSelectedCardType] = useState<string | null>(
    cardTypes[0],
  );
  const [selectedPaymentSystem, setSelectedPaymentSystem] = useState<
    string | null
  >(paymentSystems[0]);
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0]);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={canGoBack}
        title='Open new card'
        leftSideButtonClick={() => {
          if (canGoBack) {
            navigate(-1);
          } else {
            navigate('/');
          }
        }}
      />
    );
  };

  const renderBackground = () => {
    return (
      <img
        src={bg03}
        alt='bg'
        style={{
          position: 'absolute',
          width: '100%',
          height: 'auto',
          maxWidth: 'var(--screen-width)',
          margin: '0 auto',
          zIndex: 1,
        }}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          display: 'flex',
          flexDirection: 'column',
          marginLeft: 20,
          marginRight: 20,
          paddingTop: headerHeight + 10,
          zIndex: 2,
        }}
      >
        {/* Card Types */}
        <section style={{marginBottom: 14}}>
          <span
            className='t12'
            style={{display: 'block', marginBottom: 6}}
          >
            Type:
          </span>
          <div style={{display: 'flex', flexDirection: 'row', gap: 14}}>
            {cardTypes.map((type, index) => {
              return (
                <div
                  key={index}
                  style={{
                    padding: '8px 20px',
                    borderRadius: 8,
                    backgroundColor:
                      selectedCardType === type
                        ? 'var(--main-dark-color)'
                        : '#fff',
                  }}
                  onClick={() => setSelectedCardType(type)}
                >
                  <h5
                    style={{
                      color:
                        selectedCardType === type
                          ? 'var(--white-color)'
                          : 'var(--main-dark-color)',
                    }}
                  >
                    {type}
                  </h5>
                </div>
              );
            })}
          </div>
        </section>

        {/* Payment system: */}
        <section style={{marginBottom: 20}}>
          <span
            className='t12'
            style={{display: 'block', marginBottom: 6}}
          >
            Payment system:
          </span>
          <div style={{display: 'flex', flexDirection: 'row', gap: 14}}>
            {paymentSystems.map((system, index) => {
              return (
                <div
                  key={index}
                  style={{
                    padding: '10px 20px',
                    borderRadius: 8,
                    backgroundColor: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                  }}
                  onClick={() => {
                    setSelectedPaymentSystem(system);
                  }}
                >
                  <div
                    style={{
                      width: 18,
                      height: 18,
                      borderRadius: '50%',
                      border: '2px solid #CED6E1',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {selectedPaymentSystem === system && (
                      <div
                        style={{
                          width: 10,
                          height: 10,
                          backgroundColor: 'green',
                          borderRadius: '50%',
                        }}
                      />
                    )}
                  </div>
                  {system === 'Visa' && (
                    <img
                      src='https://george-fx.github.io/teofin-data/icons/04.png'
                      alt='Visa'
                      style={{width: 40.43, height: 12}}
                    />
                  )}
                  {system === 'MasterCard' && (
                    <img
                      src='https://george-fx.github.io/teofin-data/icons/05.png'
                      alt='Visa'
                      style={{width: 26.35, height: 16}}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Card */}
        <section
          className={
            styles.openNewCardSection + ' ' + styles.openNewCardSectionCard
          }
        >
          <div className={styles.openNewCardCard}>
            <span className={styles.openNewCardCardTitle}>
              teofin debet card
            </span>
            <div
              className={
                styles.openNewCardCardRow +
                ' ' +
                styles.openNewCardCardRowNumber
              }
            >
              <span className={styles.openNewCardCardNumber}>
                4325 **** **** 6475
              </span>
            </div>
            <div
              className={
                styles.openNewCardCardRow +
                ' ' +
                styles.openNewCardCardRowLabels
              }
            >
              <span
                className={
                  styles.openNewCardCardLabel +
                  ' ' +
                  styles.openNewCardCardLabelBalance
                }
              >
                balance
              </span>
              <span
                className={
                  styles.openNewCardCardLabel +
                  ' ' +
                  styles.openNewCardCardLabelExpire
                }
              >
                expire
              </span>
            </div>
            <div
              className={
                styles.openNewCardCardRow +
                ' ' +
                styles.openNewCardCardRowBottom
              }
            >
              <span className={styles.openNewCardCardBalance}>
                $ 200 000.00
              </span>
              <span className={styles.openNewCardCardExpire}>12/25</span>
            </div>
          </div>
        </section>

        {/* Descriptino */}
        <section>
          <p
            className='t16'
            style={{marginBottom: 20}}
          >
            Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur.
          </p>
        </section>

        {/* Choose currency */}
        <section style={{marginBottom: 14}}>
          <span
            className='t12'
            style={{marginBottom: 6, display: 'block'}}
          >
            Choose currency:
          </span>
          <ul style={{display: 'flex', alignItems: 'center', gap: 14}}>
            {currencies.map((currency, index) => {
              return (
                <li key={index}>
                  <div
                    style={{
                      padding: '8px 20px',
                      borderRadius: 10,
                      backgroundColor:
                        selectedCurrency === currency
                          ? 'var(--main-dark-color)'
                          : 'var(--white-color)',
                    }}
                    onClick={() => {
                      setSelectedCurrency(currency);
                    }}
                  >
                    <h5
                      style={{
                        color:
                          selectedCurrency === currency
                            ? 'var(--white-color)'
                            : 'var(--main-dark-color)',
                      }}
                    >
                      {currency}
                    </h5>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        style={{
          bottom: 0,
          width: '100%',
          paddingLeft: 20,
          paddingRight: 20,
          paddingTop: 20,
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
          position: 'fixed',
          margin: '0 auto',
          flexDirection: 'column',
          display: 'flex',
          maxWidth: 'var(--screen-width)',
          zIndex: 2,
        }}
      >
        <components.Button
          title='Add new card'
          onClick={() => {
            navigate(-1);
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderBackground()}
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
