import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {svg} from '../assets/svg';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';

import bg03 from '../assets/bg/03.png';
import styles from '../modules/forgot-password-sent-email.module.scss';

export const ForgotPasswordSentEmail: React.FC = () => {
  hooks.useThemeColor('#fff');
  hooks.useBodyColor('#fff');

  const navigate = useNavigate();

  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  const buttonRef = useRef<HTMLDivElement>(null);

  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setHeight(height);
    }
  }, []);

  const renderBackground = () => {
    return (
      <img
        src={bg03}
        alt='bg'
        className={styles.bg}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.main}
        style={{paddingBottom: height + 20}}
      >
        <svg.PasswordKeySvg />
        <h2 className={styles.title}>
          Your password <br /> has been reset!
        </h2>
        <p className={`t16 ${styles.description}`}>
          Qui ex aute ipsum duis. Incididunt adipisicing voluptate laborum
        </p>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonRef}
        className={styles.buttonWrapper}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title='Done'
          onClick={() => {
            navigate(AppRoutes.SIGN_IN, {
              replace: true,
            });
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderBackground()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
