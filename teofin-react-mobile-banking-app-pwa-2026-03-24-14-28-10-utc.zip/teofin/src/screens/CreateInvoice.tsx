import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/create-invoice.module.scss';

export const CreateIncoice: React.FC = () => {
  const navigate = useNavigate();
  const buttonsRef = useRef<HTMLDivElement>(null);
  const {headerHeight} = useAppSelector((state) => state.appReducer);
  const {safeAreaInsetBottom} = useAppSelector((state) => state.appReducer);

  const currencies = ['USD', 'EUR'];

  const [height, setHeight] = useState(0);
  const [selectedCurrency, setSelectedCurrency] = useState(currencies[0]);

  useEffect(() => {
    if (buttonsRef.current) {
      const height = buttonsRef.current.offsetHeight;
      setHeight(height);
    }
  }, []);

  const [form, setForm] = useState({
    companyName: '',
    country: '',
    companyEmail: '',
    amount: '',
    comment: '',
  });

  const handleSubmit = () => {
    navigate(AppRoutes.INVOICE_SENT, {replace: true});
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="Create invoice"
        headerStyle={{backgroundColor: '#EDF0F2'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.createInvoiceMain}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: height + 20,
        }}
      >
        {/* Inputs */}
        <section>
          <components.InputField
            placeholder="Company name"
            value={form.companyName}
            onClick={() => handleChangeField('companyName', 'company name')}
            containerStyle={{marginBottom: 14}}
          />
          <components.InputField
            placeholder="Country"
            value={form.country}
            onClick={() => handleChangeField('country', 'country')}
            containerStyle={{marginBottom: 14}}
          />
          <components.InputField
            placeholder="Company email"
            value={form.companyEmail}
            onClick={() => handleChangeField('companyEmail', 'company email')}
            containerStyle={{marginBottom: 14}}
          />
          <components.InputField
            placeholder="Amount"
            value={form.amount}
            onClick={() => handleChangeField('amount', 'amount')}
            containerStyle={{marginBottom: 14}}
          />
        </section>

        {/* Choose currency */}
        <section>
          <span className={`t12 ${styles.createInvoiceCurrencyLabel}`}>
            Choose currency:
          </span>
          <div className={styles.createInvoiceCurrencyList}>
            {currencies.map((currency) => {
              const selected = selectedCurrency === currency;
              return (
                <div
                  key={currency}
                  className={
                    styles.createInvoiceCurrencyButton +
                    (selected ? ' ' + styles.selected : '')
                  }
                  onClick={() => {
                    setSelectedCurrency(currency);
                  }}
                >
                  <h5>{currency}</h5>
                </div>
              );
            })}
          </div>
        </section>

        {/* Goods or services you provided */}
        <section>
          <components.InputField
            className={styles.inputFieldComment}
            placeholder="Goods or services you provided"
            value={form.comment}
            onClick={() => handleChangeField('comment', 'comment')}
          />
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonsRef}
        className={styles.createInvoiceButtonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title="Send invoice"
          onClick={() => {
            handleSubmit();
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
