import React, {useEffect, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';

import {hooks} from '../hooks';
import {AppRoutes} from '../routes';
import {useAppSelector} from '../store';
import {components} from '../components';
import styles from '../modules/fund-transfer.module.scss';

export const FundTransfer: React.FC = () => {
  hooks.useThemeColor('#EDF0F2');
  hooks.useBodyColor('#EDF0F2');

  const navigate = useNavigate();

  const {headerHeight, safeAreaInsetBottom} = useAppSelector(
    (state) => state.appReducer,
  );

  const buttonRef = useRef<HTMLDivElement>(null);

  const cards = [
    {
      id: 1,
      type: 'Visa',
      number: '**** **** **** 1945',
      balance: '2 648.11 USD',
    },
    {
      id: 2,
      type: 'Visa',
      number: '**** **** **** 7895',
      balance: '4 863.27 USD',
    },
  ];

  const [buttonSectionHeight, setHeight] = useState(0);
  const [selectedCard, setSelectedCard] = useState<number | null>(null);

  const [form, setForm] = useState({
    cardNumber: '',
    amount: '',
    comment: '',
  });

  const handleSend = () => {
    navigate(AppRoutes.PAYMENT_SUCCESS, {replace: true});
  };

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  useEffect(() => {
    if (buttonRef.current) {
      const height = buttonRef.current.offsetHeight;
      setHeight(height);
    }
  }, []);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title="Fund transfer"
        headerStyle={{backgroundColor: 'var(--anti-flash-white)'}}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        className={styles.container}
        style={{
          paddingTop: headerHeight + 20,
          paddingBottom: buttonSectionHeight + 20,
        }}
      >
        {/* Use card */}
        <section className={styles.cardSection}>
          <span className={`t16 ${styles.cardSectionLabel}`}>Use card:</span>
          <ul className={styles.cardList}>
            {cards.map((card) => {
              return (
                <li key={card.id}>
                  <div
                    className={
                      selectedCard === card.id
                        ? `${styles.cardItemBtn} ${styles.selected}`
                        : styles.cardItemBtn
                    }
                    onClick={() => {
                      setSelectedCard(card.id);
                    }}
                  >
                    {/* Image */}
                    <div className={styles.cardImage}>
                      <span className={styles.cardImageText}>teofin</span>
                    </div>
                    {/* Details */}
                    <>
                      <span className="t12">{card.number}</span>
                      <br />
                      <h6>{card.balance}</h6>
                    </>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Send money to: */}
        <section>
          <span className={`t16 ${styles.sendSectionLabel}`}>
            Send money to:
          </span>
          <components.InputField
            className={styles.inputField}
            placeholder="Enter card number"
            value={form.cardNumber}
            onClick={() => handleChangeField('cardNumber', 'card number')}
          />
          <components.InputField
            className={styles.inputField}
            placeholder="Amount"
            value={form.amount}
            onClick={() => handleChangeField('amount', 'amount')}
          />
          <components.InputField
            className={styles.inputFieldComment}
            placeholder="Comment"
            value={form.comment}
            onClick={() => handleChangeField('comment', 'comment')}
          />
          <span className={`t12 ${styles.bankFee}`}>Bank fee: $ 0.20</span>
        </section>
      </main>
    );
  };

  const renderButton = () => {
    return (
      <div
        ref={buttonRef}
        className={styles.buttonSection}
        style={{
          paddingBottom:
            safeAreaInsetBottom > 0
              ? safeAreaInsetBottom + 20
              : safeAreaInsetBottom + 30,
        }}
      >
        <components.Button
          title="Send"
          onClick={() => {
            handleSend();
          }}
        />
      </div>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderButton()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
