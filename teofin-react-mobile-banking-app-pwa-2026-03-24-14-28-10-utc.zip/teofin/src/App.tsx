import {useEffect} from 'react';
import {AnimatePresence} from 'framer-motion';
import {useLocation, Routes, Route} from 'react-router-dom';

import {screens} from './screens';
import {AppRoutes} from './routes';
import {useAppDispatch} from './store';
import {utils} from './utils';
import {TabNavigator} from './navigation/TabNavigator';
import {appActions} from './store/appSlice';

function App() {
  const location = useLocation();

  const dispatch = useAppDispatch();

  useEffect(() => {
    const insetTop = utils.getSafeAreaInsetTop();
    const insetBottom = utils.getSafeAreaInsetBottom();
    dispatch(appActions.setSafeAreaInsetTop(insetTop));
    dispatch(appActions.setSafeAreaInsetBottom(insetBottom));
  }, [dispatch]);

  return (
    <AnimatePresence mode='wait'>
      <Routes
        location={location}
        key={location.pathname}
      >
        <Route
          path={AppRoutes.SIGN_IN}
          element={<screens.SignIn />}
        />
        <Route
          path={AppRoutes.FORGOT_PASSWORD}
          element={<screens.ForgotPassword />}
        />
        <Route
          path={AppRoutes.SIGN_UP}
          element={<screens.SignUp />}
        />
        <Route
          path={AppRoutes.VERIFY_YOUR_PHONE_NUMBER}
          element={<screens.VerifyYourPhoneNumber />}
        />
        <Route
          path={AppRoutes.CONFIRMATION_CODE}
          element={<screens.ConfirmationCode />}
        />
        <Route
          path={AppRoutes.SIGN_UP_ACCOUNT_CREATED}
          element={<screens.SignUpAccountCreated />}
        />
        <Route
          path={AppRoutes.NEW_PASSWORD}
          element={<screens.NewPassword />}
        />
        <Route
          path={AppRoutes.FORGOT_PASSWORD_SENT_EMAIL}
          element={<screens.ForgotPasswordSentEmail />}
        />
        <Route
          path={AppRoutes.OPEN_DEPOSIT}
          element={<screens.OpenDeposit />}
        />
        <Route
          path={AppRoutes.OPEN_MONEYBOX}
          element={<screens.OpenMoneybox />}
        />
        <Route
          path={AppRoutes.OPEN_NEW_LOAN}
          element={<screens.OpenNewLoan />}
        />
        <Route
          path={AppRoutes.EDIT_PERSONAL_INFO}
          element={<screens.EditPersonalInfo />}
        />
        <Route
          path={AppRoutes.OPEN_NEW_CARD}
          element={<screens.OpenNewCard />}
        />
        <Route
          path={AppRoutes.CREATE_INVOICE}
          element={<screens.CreateIncoice />}
        />
        <Route
          path={AppRoutes.INVOICE_SENT}
          element={<screens.InvoiceSent />}
        />
        <Route
          path={AppRoutes.STATISTICS}
          element={<screens.Statistics />}
        />
        <Route
          path={AppRoutes.FAQ}
          element={<screens.FAQ />}
        />
        <Route
          path={AppRoutes.PRIVACY_POLICY}
          element={<screens.PrivacyPolicy />}
        />
        <Route
          path={AppRoutes.PROFILE}
          element={<screens.Profile />}
        />
        <Route
          path={AppRoutes.EXCHANGE_RATES}
          element={<screens.ExchangeRates />}
        />
        <Route
          path={AppRoutes.CARD_MENU}
          element={<screens.CardMenu />}
        />
        <Route
          path={AppRoutes.CARD_DETAILS}
          element={<screens.CardDetails />}
        />
        <Route
          path={AppRoutes.CHANGE_PIN_CODE}
          element={<screens.ChangePinCode />}
        />
        <Route
          path={AppRoutes.PAYMENTS}
          element={<screens.Payments />}
        />
        <Route
          path={AppRoutes.TOP_UP_PAYMENT}
          element={<screens.TopUpPayment />}
        />
        <Route
          path={AppRoutes.MOBILE_PAYMENT}
          element={<screens.MobilePayment />}
        />
        <Route
          path={AppRoutes.FUND_TRANSFER}
          element={<screens.FundTransfer />}
        />
        <Route
          path={AppRoutes.IBAN_PAYMENT}
          element={<screens.IbanPayment />}
        />
        <Route
          path={AppRoutes.TRANSACTION_HISTORY}
          element={<screens.TransactionHistory />}
        />
        <Route
          path={AppRoutes.TRANSACTION_DETAILS}
          element={<screens.TransactionDetails />}
        />
        <Route
          path={AppRoutes.PAYMENT_SUCCESS}
          element={<screens.PaymentSuccess />}
        />
        <Route
          path={AppRoutes.PAYMENT_FAILED}
          element={<screens.PaymentFailed />}
        />
        <Route
          path={AppRoutes.TAB_NAVIGATOR}
          element={<TabNavigator />}
        />
      </Routes>
    </AnimatePresence>
  );
}

export default App;
